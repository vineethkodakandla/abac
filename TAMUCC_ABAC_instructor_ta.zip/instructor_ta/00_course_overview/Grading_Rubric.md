# Consolidated Grading Rubric — TAMUCC ABAC Series

Point values align with the rubrics printed in each assignment worksheet.

## Assignment 01 — PAP (100 + 10 bonus)

| Component | Points | Assessment method |
|-----------|--------|-------------------|
| Task 1: `add_policy` (validation + persistence) | 25 | `TestTask1AddPolicy` — 10 tests |
| Task 2: `delete_policy` | 15 | `TestTask2DeletePolicy` — 5 tests |
| Task 3: `get_applicable_policies` | 25 | `TestTask3GetApplicablePolicies` — 8 tests |
| Output contract validation | 15 | `test_output_contract.py` — 3 tests |
| Code quality and docstrings | 10 | Manual review |
| Reflection docstring (3–5 sentences) | 10 | Manual review |
| **Bonus:** `detect_conflicts` | +10 | `TestBonusDetectConflicts` — 4 tests |

## Assignment 02 — PDP (100 + 10 bonus)

| Component | Points | Assessment method |
|-----------|--------|-------------------|
| Task 1: `_attrs_match` | 15 | `TestTask1AttrsMatch` — 8 tests |
| Task 2: `_matches_policy` | 20 | `TestTask2MatchesPolicy` — 6 tests |
| Task 3: First-Applicable algorithm | 25 | `TestTask3FirstApplicable` — 8 tests |
| Task 4: `_build_reason` | 10 | `TestTask4BuildReason` — 4 tests |
| Output contract validation | 10 | `test_output_contract.py` — 3 tests |
| Code quality and docstrings | 10 | Manual review |
| Reflection docstring | 10 | Manual review |
| **Bonus:** `_deny_overrides` | +10 | `TestBonusDenyOverrides` — 4 tests |

## Assignment 03 — PEP (100 + 10 bonus)

| Component | Points | Assessment method |
|-----------|--------|-------------------|
| Task 1: `build_decision_request` | 15 | `TestTask1BuildDecisionRequest` — 7 tests |
| Task 2: `enforce` | 15 | `TestTask2Enforce` — 6 tests |
| Task 3: `log_access_event` | 20 | `TestTask3LogAccessEvent` — 4 tests |
| Task 4: `apply_obligations` | 20 | `TestTask4ApplyObligations` — 5 tests |
| Output contract validation | 10 | `test_output_contract.py` — 3 tests |
| Code quality and docstrings | 10 | Manual review |
| Reflection docstring | 10 | Manual review |
| **Bonus:** `handle_indeterminate` | +10 | `TestBonusHandleIndeterminate` — 2 tests |

## Assignment 04 — Capstone (100)

| Component | Points | Assessment method |
|-----------|--------|-------------------|
| Interface conformance (all 3 ABCs) | 15 | `TestInterfaceConformance` — 3 tests |
| Shipped scenarios (12 × 2.5) | 30 | `TestScenarios::test_scenario[S01..S12]` |
| Audit trail written correctly | 10 | `TestAuditTrail` — 1 test |
| Two original scenarios | 15 | Manual: well-designed, non-trivial, TAMUCC-themed |
| Reflection document | 20 | Manual: 4 required points, depth, clarity |
| Integration cleanliness | 10 | Manual: clean imports, no hacks, ABC inheritance done properly |

### Reflection rubric breakdown (A04)

| Required element | Points |
|------------------|--------|
| One architectural decision to change (with reasoning) | 5 |
| One scenario the system cannot handle (with extension needed) | 5 |
| Why data-contract over code-dependency (1 paragraph) | 5 |
| Description of authored scenarios | 5 |

## Late policy, collaboration, academic integrity

Apply department defaults. Flag suspicious submissions by running them
through `validate_solutions.sh` and comparing test failure patterns —
students who have plagiarized often fail the same unusual edge-case tests.

## Auto-grading notes

All four assignment folders include a `validate_solutions.sh`. To
auto-grade a student submission:

```bash
cd assignment_XX/
# reset to clean state
git checkout -- . 2>/dev/null || true
# drop in student files
cp -v /submissions/Lastname-Firstname/*.py .
pytest -v --tb=short --no-header > report.txt
```

Task-grouped output lets you read off points directly:

```
TestTask1AddPolicy::test_add_valid_policy PASSED    # ← 25 pts split across 10 tests
TestTask1AddPolicy::test_reject_duplicate_id PASSED
...
```
