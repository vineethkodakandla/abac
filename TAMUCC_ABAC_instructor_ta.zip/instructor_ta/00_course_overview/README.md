# TAMUCC Agent-Based Systems — ABAC Assignment Series

**Texas A&M University – Corpus Christi**
**COSC Department**

## What you're building across the semester

Over four assignments you will build a working rule-based Attribute-Based
Access Control (ABAC) system using three cooperating agents, modeled on the
XACML architecture and grounded in real TAMUCC scenarios — Islanders viewing
grade records, COSC/MATH faculty working with Blackboard content, TAs
accessing course rosters, visitors attempting to access secure resources,
and more.

```
    ┌─────────────┐         ┌─────────────┐         ┌─────────────┐
    │    PAP      │         │    PDP      │         │    PEP      │
    │ (manages    │──JSON──▶│ (decides    │──dict──▶│ (enforces   │
    │  policies)  │         │  Permit/    │         │  decision,  │
    │             │         │  Deny)      │         │  audits)    │
    │  [A01]      │         │  [A02]      │         │  [A03]      │
    └─────────────┘         └─────────────┘         └─────────────┘
                                                           │
                                                           ▼
                                                    access_log.json
                                   │
                                   ▼
                         [A04: Capstone integration]
```

## The four assignments

| # | Title | Agent | Key concept |
|---|-------|-------|-------------|
| 01 | Policy Administration Point | PAP | CRUD on a policy store; schema validation |
| 02 | Policy Decision Point | PDP | Attribute matching; combining algorithms |
| 03 | Policy Enforcement Point | PEP | Enforcement; obligations; audit logging |
| 04 | Capstone Integration | All three | Shared interfaces; end-to-end scenarios |

## The key design principle: data contracts between agents

Every assignment is **independent**. You do not need A01 code to complete
A02, and you do not need A02 code to complete A03. The three agents
communicate through three data artifacts:

1. **`policies.json`** — produced by the PAP (A01), consumed by the PDP (A02).
2. **`decision_response` dict** — produced by the PDP (A02), consumed by the PEP (A03).
3. **`access_log.json`** — produced by the PEP (A03), consumed by auditors
   and the capstone (A04).

When you're working on A02, a pre-built `policies.json` ships with the
assignment — you don't need to have finished A01 first. When you're working
on A03, a `StubDecisionSource` stands in for the PDP — again, independent.
In the capstone you finally wire your three submissions together through
shared abstract base classes (`abac_interfaces.py`).

See `Data_Contracts_Reference.md` for the exact schemas.

## Setup (once per assignment)

```bash
pip install pytest jsonschema
cd assignment_XX_YYY/
pytest -v
```

## Consistent conventions across all assignments

- **Tests are task-grouped** by Python class. `TestTask1...`, `TestTask2...`,
  etc. Each class corresponds to one TODO in the student template.
- **Reference solutions are marked `DO_NOT_SHARE`** and shipped only to the
  instructor/TA bundle — not to students.
- **The TAMUCC environment is consistent throughout:** Islanders with IDs
  like `I12345678`, COSC and MATH faculty, TA roles, department codes
  (`cosc`, `math`, `biol`, `engr`), courses `COSC3310` / `COSC4350`, grade
  records, Blackboard content, visitor badges, and chair roles.
- **Every assignment has a "contract test"** — a pytest file that validates
  your output (JSON or dict) against a JSON Schema. Passing it is part of
  your grade.

## Expected time and difficulty

| Assignment | Approx. effort | Difficulty |
|------------|----------------|------------|
| A01 — PAP | 4–6 hours | Moderate |
| A02 — PDP | 5–8 hours | Moderate-hard (combining algorithm) |
| A03 — PEP | 5–7 hours | Moderate |
| A04 — Capstone | 3–5 hours (mostly integration + reflection) | Easy if A01–A03 are solid |

## Getting help

Office hours, Blackboard discussion boards, and your TA are your first
stops. Please do not share solutions or partial solutions — plagiarism will
be handled per university policy.

Good luck, Islanders!
