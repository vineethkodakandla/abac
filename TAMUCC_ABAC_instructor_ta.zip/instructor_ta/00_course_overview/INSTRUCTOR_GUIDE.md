# Instructor & TA Guide — TAMUCC ABAC Assignment Series

**Texas A&M University – Corpus Christi | COSC Department**
**Agent-Based Systems — Four-assignment ABAC series**

## Design philosophy

Every assignment in this series is **independent**. A student who has not
completed A01 can still complete A02, because A02 does not import any PAP
code — it reads `policies.json` directly. Similarly, A03 uses a shipped
`StubDecisionSource` rather than a PDP. In the capstone (A04) the three
agents are reconnected through ABCs in `abac_interfaces.py`.

This prevents the integrity problem of distributing A01 solution code when
some students haven't turned in A01 yet, while still preserving the
pedagogy of building a real multi-agent system.

## What's in this bundle vs the student bundle

| File | Student | Instructor/TA |
|------|---------|---------------|
| `pap.py` / `pdp.py` / `pep.py` (templates with TODOs) | ✓ | ✓ |
| `*_solution.py` (full reference implementations) | ✗ | ✓ (marked `DO_NOT_SHARE`) |
| `policies.json`, schemas, `canned_decisions.json`, `scenarios.json` | ✓ | ✓ |
| Test suites (`test_*.py`) | ✓ | ✓ |
| Worksheets (`.docx`) | ✓ | ✓ |
| `main.py` demos | ✓ | ✓ |
| `README.md` (per assignment) | ✓ | ✓ |
| `INSTRUCTOR_NOTES.md` (per assignment) | ✗ | ✓ |
| `Grading_Rubric.md` | ✗ | ✓ |
| `validate_solutions.sh` (run all tests with solutions in place) | ✗ | ✓ |

Every reference solution file has `DO_NOT_SHARE` in its header. Do not
include any `*_solution.py` file in what you distribute to students.

## Test counts (validated against reference solutions)

| Assignment | Tests | Test file |
|------------|-------|-----------|
| A01 PAP    | 30    | `test_pap.py` + `test_output_contract.py` |
| A02 PDP    | 33    | `test_pdp.py` + `test_output_contract.py` |
| A03 PEP    | 27    | `test_pep.py` + `test_output_contract.py` |
| A04 Capstone | 16  | `test_integration.py` |
| **Total** | **106** | |

Run `validate_solutions.sh` in each assignment folder before distributing to
confirm all tests pass with the reference solution in place.

## Release timing recommendation

- **Week 1:** Release A01 + course overview + data contracts reference.
- **Week 3:** Release A02. The data-contract design means students who
  haven't finished A01 can still start A02 immediately.
- **Week 5:** Release A03. Same independence property — the stub decision
  source means A02 is not required.
- **Week 7:** Release A04. At this point students who finished A01–A03
  have everything they need. Students still finishing earlier assignments
  can complete them in parallel — the capstone itself only takes 3–5 hours
  once their three agents are done.

## Grading workflow

Each assignment ships with a `validate_solutions.sh` script (instructor
bundle only). To grade a student submission:

```bash
cd assignment_XX_YYY/
cp /path/to/student/submission/*.py .
pytest -v --tb=short > results.txt
```

The tests are task-grouped (one class per TODO), so test output maps
directly onto the grading rubric in each worksheet.

## Known edge cases and gotchas

### A01
- Students sometimes implement `get_applicable_policies` as an **exact**
  match rather than a loose filter. Tests cover this: if the request
  doesn't specify a subject key that the policy requires, the policy must
  still be included.
- The `test_reject_non_dict_policy` case catches students who forget to
  guard against non-dict inputs (strings, `None`, integers).

### A02
- **Priority semantics:** lower number = higher precedence. This is
  counterintuitive for some students. Emphasize this in lecture.
- **Empty subject policy:** a policy with `"subject": {}` is a wildcard —
  it matches anything. Several tests exercise this.
- **Priority ties:** the current implementation uses Python's stable sort.
  If you add tie-breaking tests, be explicit about the tiebreaker.

### A03
- Students sometimes put business logic in the obligation handlers
  (`_obligation_*` methods) instead of treating them as simple dispatch.
  The scaffolding provides these handlers already — students only need to
  implement the **dispatch** (`apply_obligations`).
- **Do not allow** students to modify `stub_decision_source.py`. The
  assignment explicitly forbids this and the tests depend on its behavior.
- Timestamp format must be `datetime.now(timezone.utc).isoformat()`. Some
  students use `datetime.utcnow()` which is naive and sortable differently.

### A04
- Some students try to "cheat" by rewriting earlier agents from scratch
  instead of reusing their own A01/A02/A03. This is fine as long as the
  integration tests pass — but the reflection document must acknowledge
  what they changed.
- The `test_scenario[S08]` and `test_scenario[S09]` cases both expect
  `NotApplicable`. This is correct: in the default `first_applicable`
  algorithm, if no policy matches, the decision is `NotApplicable`, not
  `Deny`. (`Deny` is a PEP-level outcome when it enforces the decision.)

## Reporting issues

If you find a bug in a test, a confusing worksheet section, or an
ambiguous grading criterion, note it in your TA notes and flag it for the
next semester's revision.
