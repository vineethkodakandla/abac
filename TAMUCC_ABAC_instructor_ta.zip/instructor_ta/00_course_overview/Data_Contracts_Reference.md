# Data Contracts Reference — TAMUCC ABAC Series

This is the authoritative reference for the three data contracts that connect
the four assignments. Keep it handy.

## 1. Policy Store — `policies.json`

**Produced by:** PAP (A01)
**Consumed by:** PDP (A02), Capstone (A04)
**Schema:** `policies.schema.json`

A JSON array of policy objects. Each object:

```json
{
  "policy_id":   "P001",
  "description": "Short human-readable description",
  "effect":      "Permit",
  "subject":     {"role": "faculty", "department": "cosc"},
  "action":      "view_grade",
  "resource":    {"type": "grade_record", "department": "cosc"},
  "priority":    10
}
```

| Field | Type | Notes |
|-------|------|-------|
| `policy_id` | string | Unique across the store |
| `description` | string | Free text — used in the audit reason |
| `effect` | string | `"Permit"` or `"Deny"` |
| `subject` | object | Attribute dict; `{}` means "any subject" |
| `action` | string | Action verb, or `"*"` for any action |
| `resource` | object | Attribute dict; `{}` means "any resource" |
| `priority` | integer | Lower number = higher precedence |

Optional: `obligations` — array of obligation dicts passed through to the PEP.

## 2. Decision Request (PEP → PDP)

**Produced by:** PEP (A03), raw requests normalized by `build_decision_request()`
**Consumed by:** PDP (A02) `.evaluate()`

```json
{
  "request_id": "REQ-001",
  "subject":    {"id": "I12345678", "role": "student"},
  "action":     "view_grade",
  "resource":   {"type": "grade_record", "owner": "self"}
}
```

## 3. Decision Response (PDP → PEP)

**Produced by:** PDP (A02) `.evaluate()`
**Consumed by:** PEP (A03)
**Schema:** `decision_response.schema.json`

```json
{
  "request_id":     "REQ-001",
  "decision":       "Permit",
  "matched_policy": "P001",
  "reason":         "Decision=Permit because policy P001 ('...') matched with priority 10.",
  "obligations":    []
}
```

| Field | Values |
|-------|--------|
| `decision` | `"Permit"`, `"Deny"`, `"NotApplicable"`, `"Indeterminate"` |
| `matched_policy` | policy_id string, or `null` if none matched |
| `reason` | Human-readable justification — ends up in the audit log |
| `obligations` | Passed through from matched policy; `[]` if none |

## 4. Audit Log — `access_log.json`

**Produced by:** PEP (A03)
**Consumed by:** Capstone (A04), auditors
**Schema:** `access_log.schema.json`

A JSON array of audit records. Each record:

```json
{
  "timestamp": "2026-04-23T12:34:56.789+00:00",
  "request":   { /* decision request */ },
  "response":  { /* decision response */ },
  "enforced":  true
}
```

`enforced` is `true` iff the decision was `Permit` and the PEP allowed the
action.

## 5. Shared TAMUCC vocabulary

Consistent across all four assignments:

| Role | Example ID |
|------|------------|
| `student` (Islander) | `I12345678` |
| `faculty` | `F001` |
| `ta` | `I87654321` |
| `chair` | — |
| `visitor` | `badge_id: "VISITOR-001"` |

| Department codes | `cosc`, `math`, `biol`, `engr` |
| Courses | `COSC3310`, `COSC4350`, etc. |
| Resource types | `grade_record`, `course_roster`, `blackboard_content`, `lab` |
| Actions | `view_grade`, `modify_grade`, `view_roster`, `upload_content`, `access_secure_lab`, `view_content` |

## 6. Capstone Interfaces — `abac_interfaces.py`

In A04, each agent inherits from a matching ABC:

```python
class PAPInterface(ABC):
    def add_policy(self, policy) -> bool: ...
    def delete_policy(self, policy_id) -> bool: ...
    def get_applicable_policies(self, request_attrs) -> list: ...

class PDPInterface(ABC):
    def evaluate(self, request) -> dict: ...

class PEPInterface(ABC):
    def handle(self, raw_request) -> dict: ...
```

These thin ABCs are the glue that reconnects the three independently-built
agents into one system.
