"""
TAMUCC Agent-Based Systems | Assignment 03
Stub Decision Source

This is NOT a Policy Decision Point. It is a test stub that pretends to be a PDP
by returning canned decision responses from a JSON file. We use this so your PEP
can be built and graded WITHOUT depending on Assignment 02 code.

In the capstone (Assignment 04) you will replace this stub with your real PDP
from Assignment 02. They expose the same `.evaluate(request)` interface.

DO NOT modify this file - the tests depend on its behavior.
"""
import json
from typing import Dict, Any, List


class StubDecisionSource:
    """
    A fake PDP for testing the PEP in isolation.
    Looks up responses by (subject, action, resource) in a canned JSON file.
    Returns {"decision": "NotApplicable", ...} for any request not found.
    """

    def __init__(self, canned_path: str = "canned_decisions.json"):
        self.canned_path = canned_path
        with open(canned_path, "r") as f:
            self._entries: List[Dict[str, Any]] = json.load(f)

    def _key(self, request: Dict[str, Any]) -> str:
        """Build a stable lookup key from the request."""
        subj = json.dumps(request.get("subject", {}), sort_keys=True)
        act = request.get("action", "")
        res = json.dumps(request.get("resource", {}), sort_keys=True)
        return f"{subj}|{act}|{res}"

    def evaluate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Match the request against canned entries; return that response or NotApplicable."""
        target = self._key(request)
        for entry in self._entries:
            if self._key(entry["request"]) == target:
                resp = dict(entry["response"])
                resp["request_id"] = request.get("request_id")
                return resp
        return {
            "request_id": request.get("request_id"),
            "decision": "NotApplicable",
            "matched_policy": None,
            "reason": "Stub: no canned decision found for this request.",
            "obligations": []
        }
