# Assignment 03 — Instructor Notes (PEP)

## Learning objective alignment

This assignment covers (1) input normalization at a trust boundary, (2)
safe-default-deny enforcement semantics, (3) structured audit logging with
UTC timestamps, (4) obligation dispatch patterns, and optionally (5) retry
logic for uncertain decisions.

## Method 1 decoupling

**The PEP does NOT import the PDP.** Instead it uses `StubDecisionSource`,
a ~30-line class shipped with the assignment that reads canned responses
from `canned_decisions.json`. The stub exposes the same `evaluate(request)`
interface a real PDP would, so in the capstone students simply swap one
for the other.

**Do not permit** students to modify `stub_decision_source.py`. The tests
depend on its exact behavior, and modifying it is a shortcut around the
actual assignment.

## Reference solution

`pep_solution.py` — drop-in complete implementation including the bonus
`handle_indeterminate`. Marked `DO_NOT_SHARE`. All 27 tests pass.

## Expected student stumbling points

1. **Input aliases.** The `build_decision_request` method accepts three
   aliases: `user → subject`, `operation → action`, `target → resource`.
   Students sometimes handle only the canonical names. Four tests exercise
   each alias individually.

2. **`NotApplicable` ≠ `Deny` at the PDP level, but both are DENIED at the
   PEP level.** This is a subtle but important point. The PDP returns
   `NotApplicable` when no policy matched (no decision was made). The PEP
   converts this to a DENIED outcome because the system's default is to
   deny access unless explicitly permitted. Same for `Indeterminate`.

3. **Timestamp format.** Must be `datetime.now(timezone.utc).isoformat()`.
   Some students use `datetime.utcnow()` which produces a naive datetime
   that doesn't sort correctly with other timezone-aware timestamps. The
   schema accepts both, so the test won't catch it — note this in manual
   review.

4. **Log file bootstrap.** If `access_log.json` doesn't exist, they must
   create it as an empty list first before appending. `test_creates_file`
   catches this.

5. **Unknown obligation handling.** Students sometimes raise an exception
   on unknown obligation types. The correct behavior is to append
   `{"type": <type>, "status": "unknown"}` and continue. This models
   real-world policy systems where unknown obligations are logged but
   don't block enforcement.

6. **Obligation handlers are provided.** Students only need to implement
   the *dispatch* in `apply_obligations`. A surprising number try to
   reimplement the handlers themselves — easy to catch in manual review.

## Running validation

```bash
cd instructor_ta/assignment_03_pep/
bash validate_solutions.sh
# Expected: 27 passed
```

## Canned decisions fixture

`canned_decisions.json` has 6 entries covering:

- Normal Permit with a simple log obligation
- Permit with no obligations (Islander own grade)
- Deny with `notify_admin` obligation
- Permit with `mask_fields` obligation (TA viewing roster)
- Deny for sealed records
- **Indeterminate** decision for visitor badge scenario (exercises bonus task)

The stub key function joins subject + action + resource into a deterministic
lookup key. If you add entries, remember that key order matters for
`json.dumps(..., sort_keys=True)` — attribute order in the dict does not,
but the stub key does the sorting for you.

## Common manual-review items

- Is the pipeline method (`handle`) untouched? They shouldn't modify it.
- Did they respect the instruction NOT to modify `stub_decision_source.py`?
- Is their reflection meaningful or a single-sentence cop-out?

## Grading tip

`TestTask2Enforce::test_not_applicable_raises` is the diagnostic for the
"safe default deny" concept. A student who returns `"DENIED"` for
`NotApplicable` instead of raising fails only this case.
