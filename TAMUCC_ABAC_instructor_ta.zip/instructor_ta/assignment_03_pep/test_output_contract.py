"""
TAMUCC Agent-Based Systems | Assignment 03
Output Contract Test

Your PEP's audit log is consumed by downstream auditing/capstone code.
Every record must validate against access_log.schema.json.
"""
import json
import os
import pytest
from jsonschema import validate
from pep import PEP
from stub_decision_source import StubDecisionSource


@pytest.fixture
def schema():
    path = os.path.join(os.path.dirname(__file__), "access_log.schema.json")
    with open(path) as f:
        return json.load(f)


@pytest.fixture
def pep(tmp_path):
    canned = os.path.join(os.path.dirname(__file__), "canned_decisions.json")
    log = tmp_path / "access_log.json"
    stub = StubDecisionSource(canned_path=canned)
    return PEP(decision_source=stub, log_path=str(log))


class TestAuditLogContract:

    def test_log_after_permit(self, pep, schema):
        raw = {
            "subject": {"role": "faculty", "department": "cosc", "id": "F001"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc", "course": "COSC3310"}
        }
        pep.handle(raw)
        with open(pep.log_path) as f:
            log = json.load(f)
        validate(instance=log, schema=schema)

    def test_log_after_deny(self, pep, schema):
        raw = {
            "subject": {"role": "student", "id": "I99999999"},
            "action": "modify_grade",
            "resource": {"type": "grade_record"}
        }
        pep.handle(raw)
        with open(pep.log_path) as f:
            log = json.load(f)
        validate(instance=log, schema=schema)

    def test_log_multiple(self, pep, schema):
        for raw in [
            {"subject": {"role": "faculty", "department": "cosc", "id": "F001"},
             "action": "view_grade",
             "resource": {"type": "grade_record", "department": "cosc", "course": "COSC3310"}},
            {"subject": {"role": "student", "id": "I12345678"},
             "action": "view_grade",
             "resource": {"type": "grade_record", "owner": "self"}},
            {"subject": {"role": "student", "id": "I99999999"},
             "action": "modify_grade",
             "resource": {"type": "grade_record"}},
        ]:
            pep.handle(raw)
        with open(pep.log_path) as f:
            log = json.load(f)
        assert len(log) == 3
        validate(instance=log, schema=schema)
