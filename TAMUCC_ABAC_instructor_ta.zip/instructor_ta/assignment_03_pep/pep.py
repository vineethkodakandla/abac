"""
TAMUCC Agent-Based Systems | Assignment 03
Policy Enforcement Point (PEP) - Student Template

Your job: implement the five methods marked with TODO (4 required + 1 bonus).

The PEP sits between the incoming request and the actual resource. It:
  1. Normalizes the incoming request into a canonical decision request.
  2. Asks a "decision source" (PDP) for a decision.
  3. Enforces that decision (allow or deny).
  4. Applies any obligations (logging, notifying admins, masking fields, etc.).
  5. Writes a structured audit record.

IMPORTANT: This PEP works with a StubDecisionSource (shipped with this
assignment). You do NOT need Assignment 02 code. In the capstone (Assignment 04)
you will swap the stub for your real PDP - they share the same
`.evaluate(request)` interface.

Run tests with:  pytest -v
Run the demo:    python main.py
"""
import json
import os
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List


class AccessDeniedError(Exception):
    """Raised when the PEP denies an access request."""
    pass


class PEP:

    def __init__(self, decision_source, log_path: str = "access_log.json"):
        self.decision_source = decision_source
        self.log_path = log_path
        self.obligation_handlers = {
            "log": self._obligation_log,
            "notify_admin": self._obligation_notify_admin,
            "mask_fields": self._obligation_mask_fields,
            "require_reauth": self._obligation_require_reauth,
        }

    # ---------- TASK 1 ----------
    def build_decision_request(self, raw_request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize an incoming raw request to the canonical schema:
            {"request_id": "...", "subject": {...}, "action": "...", "resource": {...}}

        Support these raw input aliases:
          - "user"       is an alias for "subject"
          - "operation"  is an alias for "action"
          - "target"     is an alias for "resource"

        If no request_id is provided, generate one using self._generate_request_id().
        Missing subject/resource -> empty dict. Missing action -> empty string.
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 2 ----------
    def enforce(self, decision_response: Dict[str, Any]) -> str:
        """
        Turn a decision into a concrete outcome:
          - "Permit"        -> return the string "ALLOWED"
          - "Deny"          -> raise AccessDeniedError
          - "NotApplicable" -> raise AccessDeniedError (default deny)
          - "Indeterminate" -> raise AccessDeniedError (safe default)
          - unknown value   -> raise AccessDeniedError

        Include the decision label and the reason in the exception message.
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 3 ----------
    def log_access_event(self, request: Dict[str, Any],
                         response: Dict[str, Any],
                         enforced: bool) -> None:
        """
        Append a structured audit record to self.log_path (JSON array).

        Record shape:
            {
              "timestamp": "<UTC ISO timestamp>",
              "request":   <the decision request>,
              "response":  <the decision response>,
              "enforced":  <True if Permit, False otherwise>
            }

        If the log file doesn't exist yet, create it as an empty list first.
        Use datetime.now(timezone.utc).isoformat() for the timestamp.
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 4 ----------
    def apply_obligations(self, response: Dict[str, Any],
                          context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Execute each obligation listed in response["obligations"].

        For each obligation dict:
          - look up a handler in self.obligation_handlers by obligation["type"]
          - if found, call handler(obligation, context) and collect the result
          - if not found, append {"type": <type>, "status": "unknown"}

        Return the list of results.
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- BONUS TASK ----------
    def handle_indeterminate(self, request: Dict[str, Any],
                             response: Dict[str, Any]) -> Dict[str, Any]:
        """
        BONUS: Deal with an Indeterminate decision.

        Strategy:
          1. Build a REDUCED request containing only "role" and "badge_id" from
             the original subject (drop noisy attributes like session id, IP, etc.).
             Keep action and resource as-is.
          2. Call self.decision_source.evaluate(reduced_request) once more.
          3. If the retry is still Indeterminate, return a safe-default Deny response:
               {
                 "request_id": <orig request_id>,
                 "decision": "Deny",
                 "matched_policy": None,
                 "reason": "Indeterminate after retry; default Deny.",
                 "obligations": []
               }
          4. Otherwise return the retry response.
        """
        # TODO: implement (bonus, optional)
        raise NotImplementedError

    # ---------- obligation handlers (provided, do not modify) ----------
    def _obligation_log(self, ob, context):
        return {"type": "log", "status": "executed",
                "level": ob.get("level", "info")}

    def _obligation_notify_admin(self, ob, context):
        return {"type": "notify_admin", "status": "sent",
                "reason": ob.get("reason", "")}

    def _obligation_mask_fields(self, ob, context):
        return {"type": "mask_fields", "status": "applied",
                "fields": ob.get("fields", [])}

    def _obligation_require_reauth(self, ob, context):
        return {"type": "require_reauth", "status": "prompted"}

    def _generate_request_id(self) -> str:
        return f"REQ-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}"

    # ---------- high-level pipeline (provided, do not modify) ----------
    def handle(self, raw_request: Dict[str, Any]) -> Dict[str, Any]:
        """Run the full PEP pipeline for one incoming request."""
        request = self.build_decision_request(raw_request)
        response = self.decision_source.evaluate(request)
        if response.get("decision") == "Indeterminate":
            try:
                response = self.handle_indeterminate(request, response)
            except NotImplementedError:
                pass
        try:
            outcome = self.enforce(response)
            enforced = True
        except AccessDeniedError:
            outcome = "DENIED"
            enforced = False
        ob_results = self.apply_obligations(response, {"request": request})
        self.log_access_event(request, response, enforced)
        return {"outcome": outcome, "response": response, "obligations": ob_results}
