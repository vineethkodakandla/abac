# Assignment 03 — Policy Enforcement Point (PEP)

**Texas A&M University – Corpus Christi**
**COSC Department | Agent-Based Systems**

## What you're building

The Policy Enforcement Point — the agent that sits between an incoming
request and the resource being protected. It normalizes the request, asks
a decision source for a decision, enforces the result, applies obligations,
and writes an audit log. You implement five methods in `pep.py` (four
required, one bonus).

See `Assignment_03_Worksheet.docx` for the full specification.

## Important: This assignment is independent of Assignment 02

Your PEP talks to a `StubDecisionSource` class (shipped with this
assignment) that reads canned responses from `canned_decisions.json`. The
stub exposes the same `evaluate(request)` interface a real PDP would, so in
the capstone you simply swap one for the other.

**Do not modify `stub_decision_source.py`** — tests rely on its exact
behavior.

## Files in this directory

| File | Purpose |
|------|---------|
| `pep.py` | Student template with TODO blocks — edit this |
| `stub_decision_source.py` | Fake PDP for testing — **do not modify** |
| `canned_decisions.json` | Canned decision responses the stub returns |
| `access_log.schema.json` | Output contract for the audit log |
| `test_pep.py` | Task-grouped pytest suite — 24 test cases |
| `test_output_contract.py` | Validates audit log format |
| `main.py` | TAMUCC-themed demo |
| `Assignment_03_Worksheet.docx` | Full written spec + grading rubric |

## Setup

```bash
pip install pytest jsonschema
```

## Run

```bash
pytest -v
python main.py          # writes access_log.json
```

## Submission

Zip file `Last-First-A03.zip` containing `pep.py` → submit on Blackboard.
