"""
TAMUCC Agent-Based Systems | Assignment 03 Tests
Policy Enforcement Point (PEP)

Tests grouped by task class. The PEP is tested against a StubDecisionSource
that returns canned responses - NO Assignment 02 code is required.

Run with:  pytest -v
"""
import json
import os
import pytest
from pep import PEP, AccessDeniedError
from stub_decision_source import StubDecisionSource


@pytest.fixture
def canned_path():
    return os.path.join(os.path.dirname(__file__), "canned_decisions.json")


@pytest.fixture
def stub(canned_path):
    return StubDecisionSource(canned_path=canned_path)


@pytest.fixture
def pep(stub, tmp_path):
    log = tmp_path / "access_log.json"
    return PEP(decision_source=stub, log_path=str(log))


# =====================================================================
# TASK 1: build_decision_request
# =====================================================================
class TestTask1BuildDecisionRequest:

    def test_canonical_input_passthrough(self, pep):
        raw = {
            "request_id": "R1",
            "subject": {"role": "faculty"},
            "action": "view_grade",
            "resource": {"type": "grade_record"}
        }
        result = pep.build_decision_request(raw)
        assert result["request_id"] == "R1"
        assert result["subject"] == {"role": "faculty"}
        assert result["action"] == "view_grade"
        assert result["resource"] == {"type": "grade_record"}

    def test_user_aliased_to_subject(self, pep):
        raw = {"user": {"role": "ta"}, "action": "x", "resource": {}}
        result = pep.build_decision_request(raw)
        assert result["subject"] == {"role": "ta"}

    def test_operation_aliased_to_action(self, pep):
        raw = {"subject": {}, "operation": "view", "resource": {}}
        result = pep.build_decision_request(raw)
        assert result["action"] == "view"

    def test_target_aliased_to_resource(self, pep):
        raw = {"subject": {}, "action": "view", "target": {"type": "grade"}}
        result = pep.build_decision_request(raw)
        assert result["resource"] == {"type": "grade"}

    def test_request_id_generated(self, pep):
        raw = {"subject": {}, "action": "x", "resource": {}}
        result = pep.build_decision_request(raw)
        assert result["request_id"]
        assert result["request_id"].startswith("REQ-")

    def test_missing_fields_default_safely(self, pep):
        raw = {}
        result = pep.build_decision_request(raw)
        assert result["subject"] == {}
        assert result["resource"] == {}
        assert result["action"] == ""

    def test_has_four_canonical_keys(self, pep):
        raw = {"subject": {}, "action": "x", "resource": {}}
        result = pep.build_decision_request(raw)
        assert set(result.keys()) == {"request_id", "subject", "action", "resource"}


# =====================================================================
# TASK 2: enforce
# =====================================================================
class TestTask2Enforce:

    def test_permit_allowed(self, pep):
        resp = {"decision": "Permit", "reason": "ok"}
        assert pep.enforce(resp) == "ALLOWED"

    def test_deny_raises(self, pep):
        resp = {"decision": "Deny", "reason": "no"}
        with pytest.raises(AccessDeniedError):
            pep.enforce(resp)

    def test_not_applicable_raises(self, pep):
        resp = {"decision": "NotApplicable", "reason": "none"}
        with pytest.raises(AccessDeniedError):
            pep.enforce(resp)

    def test_indeterminate_raises(self, pep):
        resp = {"decision": "Indeterminate", "reason": "?"}
        with pytest.raises(AccessDeniedError):
            pep.enforce(resp)

    def test_unknown_decision_raises(self, pep):
        resp = {"decision": "Maybe", "reason": "meh"}
        with pytest.raises(AccessDeniedError):
            pep.enforce(resp)

    def test_error_contains_reason(self, pep):
        resp = {"decision": "Deny", "reason": "default policy"}
        try:
            pep.enforce(resp)
        except AccessDeniedError as e:
            assert "default policy" in str(e)


# =====================================================================
# TASK 3: log_access_event
# =====================================================================
class TestTask3LogAccessEvent:

    def test_creates_file(self, pep):
        req = {"request_id": "L1", "subject": {}, "action": "x", "resource": {}}
        resp = {"decision": "Permit", "reason": "ok",
                "matched_policy": "P001", "obligations": []}
        pep.log_access_event(req, resp, enforced=True)
        assert os.path.exists(pep.log_path)

    def test_appends_multiple(self, pep):
        req = {"request_id": "L2", "subject": {}, "action": "x", "resource": {}}
        resp = {"decision": "Permit", "reason": "ok",
                "matched_policy": "P001", "obligations": []}
        pep.log_access_event(req, resp, True)
        pep.log_access_event(req, resp, True)
        pep.log_access_event(req, resp, False)
        with open(pep.log_path) as f:
            log = json.load(f)
        assert len(log) == 3

    def test_record_has_required_keys(self, pep):
        req = {"request_id": "L3", "subject": {}, "action": "x", "resource": {}}
        resp = {"decision": "Deny", "reason": "no",
                "matched_policy": "P004", "obligations": []}
        pep.log_access_event(req, resp, False)
        with open(pep.log_path) as f:
            log = json.load(f)
        for key in ("timestamp", "request", "response", "enforced"):
            assert key in log[-1]

    def test_enforced_flag(self, pep):
        req = {"request_id": "L4", "subject": {}, "action": "x", "resource": {}}
        resp_p = {"decision": "Permit", "reason": "ok", "obligations": []}
        resp_d = {"decision": "Deny", "reason": "no", "obligations": []}
        pep.log_access_event(req, resp_p, True)
        pep.log_access_event(req, resp_d, False)
        with open(pep.log_path) as f:
            log = json.load(f)
        assert log[0]["enforced"] is True
        assert log[1]["enforced"] is False


# =====================================================================
# TASK 4: apply_obligations
# =====================================================================
class TestTask4ApplyObligations:

    def test_no_obligations(self, pep):
        resp = {"obligations": []}
        result = pep.apply_obligations(resp, {})
        assert result == []

    def test_log_obligation(self, pep):
        resp = {"obligations": [{"type": "log", "level": "info"}]}
        result = pep.apply_obligations(resp, {})
        assert len(result) == 1
        assert result[0]["type"] == "log"
        assert result[0]["status"] == "executed"

    def test_multiple_obligations(self, pep):
        resp = {"obligations": [
            {"type": "log", "level": "info"},
            {"type": "notify_admin", "reason": "denied"},
            {"type": "mask_fields", "fields": ["ssn"]}
        ]}
        result = pep.apply_obligations(resp, {})
        assert len(result) == 3
        assert {r["type"] for r in result} == {"log", "notify_admin", "mask_fields"}

    def test_unknown_obligation_marked(self, pep):
        resp = {"obligations": [{"type": "self_destruct"}]}
        result = pep.apply_obligations(resp, {})
        assert result[0]["status"] == "unknown"

    def test_mask_fields_carries_payload(self, pep):
        resp = {"obligations": [{"type": "mask_fields", "fields": ["ssn", "dob"]}]}
        result = pep.apply_obligations(resp, {})
        assert "ssn" in result[0]["fields"]
        assert "dob" in result[0]["fields"]


# =====================================================================
# BONUS: handle_indeterminate
# =====================================================================
class TestBonusHandleIndeterminate:

    def test_indeterminate_retry_returns_deny_default(self, pep):
        # The canned source returns Indeterminate for VISITOR-001 on this request.
        # When we reduce, the reduced request no longer matches any canned entry
        # (retry will be NotApplicable, not Indeterminate) - so the retry value passes through.
        req = {
            "request_id": "IND1",
            "subject": {"badge_id": "VISITOR-001", "session": "abc"},
            "action": "access_secure_lab",
            "resource": {"type": "lab", "building": "engineering"}
        }
        resp = {"decision": "Indeterminate", "reason": "conflict",
                "matched_policy": None, "obligations": []}
        result = pep.handle_indeterminate(req, resp)
        # The reduced request's key differs from canned -> NotApplicable on retry
        assert result["decision"] in ("NotApplicable", "Deny")

    def test_indeterminate_twice_default_deny(self, pep, tmp_path):
        # Create a stub that always returns Indeterminate
        class AlwaysIndet:
            def evaluate(self, request):
                return {"request_id": request.get("request_id"),
                        "decision": "Indeterminate", "reason": "always",
                        "matched_policy": None, "obligations": []}
        pep.decision_source = AlwaysIndet()
        req = {"request_id": "IND2", "subject": {"role": "x"},
               "action": "y", "resource": {}}
        resp = {"decision": "Indeterminate", "reason": "always",
                "matched_policy": None, "obligations": []}
        result = pep.handle_indeterminate(req, resp)
        assert result["decision"] == "Deny"
        assert "after retry" in result["reason"]
