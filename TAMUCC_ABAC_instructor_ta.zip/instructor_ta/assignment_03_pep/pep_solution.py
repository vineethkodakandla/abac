"""
TAMUCC Agent-Based Systems | Assignment 03
Policy Enforcement Point (PEP) - INSTRUCTOR REFERENCE SOLUTION
DO_NOT_SHARE with students.
"""
import json
import os
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List


class AccessDeniedError(Exception):
    """Raised when the PEP denies an access request."""
    pass


class PEP:
    """
    Policy Enforcement Point.

    Sits between the request source (e.g. Blackboard handler) and the
    resource. Builds a normalized decision request, asks a decision source
    (a PDP, or in testing a stub), enforces the decision, applies obligations,
    and logs the access event.
    """

    def __init__(self, decision_source, log_path: str = "access_log.json"):
        self.decision_source = decision_source
        self.log_path = log_path
        self.obligation_handlers = {
            "log": self._obligation_log,
            "notify_admin": self._obligation_notify_admin,
            "mask_fields": self._obligation_mask_fields,
            "require_reauth": self._obligation_require_reauth,
        }

    # ---------- TASK 1 ----------
    def build_decision_request(self, raw_request: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize a raw incoming request into the canonical decision request shape."""
        subject = raw_request.get("subject") or raw_request.get("user") or {}
        action = raw_request.get("action") or raw_request.get("operation") or ""
        resource = raw_request.get("resource") or raw_request.get("target") or {}
        request_id = raw_request.get("request_id") or self._generate_request_id()
        return {
            "request_id": request_id,
            "subject": subject,
            "action": action,
            "resource": resource,
        }

    # ---------- TASK 2 ----------
    def enforce(self, decision_response: Dict[str, Any]) -> str:
        """
        Turn a decision into a concrete outcome.

        Permit        -> return "ALLOWED"
        Deny          -> raise AccessDeniedError
        NotApplicable -> raise AccessDeniedError (default deny)
        Indeterminate -> raise AccessDeniedError (safe default)
        """
        decision = decision_response.get("decision")
        reason = decision_response.get("reason", "")
        if decision == "Permit":
            return "ALLOWED"
        if decision in ("Deny", "NotApplicable", "Indeterminate"):
            raise AccessDeniedError(f"{decision}: {reason}")
        raise AccessDeniedError(f"Unknown decision: {decision}")

    # ---------- TASK 3 ----------
    def log_access_event(self, request: Dict[str, Any],
                         response: Dict[str, Any],
                         enforced: bool) -> None:
        """Append a structured audit record to self.log_path."""
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "request": request,
            "response": response,
            "enforced": enforced,
        }
        if os.path.exists(self.log_path):
            with open(self.log_path, "r") as f:
                log = json.load(f)
        else:
            log = []
        log.append(record)
        with open(self.log_path, "w") as f:
            json.dump(log, f, indent=2)

    # ---------- TASK 4 ----------
    def apply_obligations(self, response: Dict[str, Any],
                          context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Execute each obligation listed in the response. Return execution results."""
        results = []
        for ob in response.get("obligations", []):
            handler = self.obligation_handlers.get(ob.get("type"))
            if handler is None:
                results.append({"type": ob.get("type"), "status": "unknown"})
                continue
            result = handler(ob, context)
            results.append(result)
        return results

    # ---------- BONUS TASK ----------
    def handle_indeterminate(self, request: Dict[str, Any],
                             response: Dict[str, Any]) -> Dict[str, Any]:
        """
        BONUS: fallback for Indeterminate responses. Re-query once with
        a reduced request (just subject/action/resource keys), then fall back
        to a Deny response if still Indeterminate.
        """
        reduced = {
            "request_id": request.get("request_id"),
            "subject": {k: v for k, v in request.get("subject", {}).items()
                        if k in ("role", "badge_id")},
            "action": request.get("action"),
            "resource": request.get("resource", {}),
        }
        retry = self.decision_source.evaluate(reduced)
        if retry.get("decision") == "Indeterminate":
            return {
                "request_id": request.get("request_id"),
                "decision": "Deny",
                "matched_policy": None,
                "reason": "Indeterminate after retry; default Deny.",
                "obligations": [],
            }
        return retry

    # ---------- obligation handlers (provided) ----------
    def _obligation_log(self, ob, context):
        return {"type": "log", "status": "executed",
                "level": ob.get("level", "info")}

    def _obligation_notify_admin(self, ob, context):
        return {"type": "notify_admin", "status": "sent",
                "reason": ob.get("reason", "")}

    def _obligation_mask_fields(self, ob, context):
        return {"type": "mask_fields", "status": "applied",
                "fields": ob.get("fields", [])}

    def _obligation_require_reauth(self, ob, context):
        return {"type": "require_reauth", "status": "prompted"}

    def _generate_request_id(self) -> str:
        return f"REQ-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}"

    # ---------- Public high-level API ----------
    def handle(self, raw_request: Dict[str, Any]) -> Dict[str, Any]:
        """Full pipeline: normalize -> decide -> enforce -> log -> obligations."""
        request = self.build_decision_request(raw_request)
        response = self.decision_source.evaluate(request)
        if response.get("decision") == "Indeterminate":
            try:
                response = self.handle_indeterminate(request, response)
            except NotImplementedError:
                pass
        try:
            outcome = self.enforce(response)
            enforced = True
        except AccessDeniedError:
            outcome = "DENIED"
            enforced = False
        ob_results = self.apply_obligations(response, {"request": request})
        self.log_access_event(request, response, enforced)
        return {"outcome": outcome, "response": response, "obligations": ob_results}
