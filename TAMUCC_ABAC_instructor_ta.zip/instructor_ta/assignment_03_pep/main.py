"""
TAMUCC Agent-Based Systems | Assignment 03 Demo
Policy Enforcement Point (PEP)

Walks through several TAMUCC scenarios showing how the PEP turns
an incoming request into an enforced outcome using a StubDecisionSource.
"""
import json
import os
from pep import PEP, AccessDeniedError
from stub_decision_source import StubDecisionSource


def banner(title):
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)


def show(raw, result):
    print(f"RAW INPUT:  {raw}")
    print(f"OUTCOME:    {result['outcome']}")
    print(f"DECISION:   {result['response'].get('decision')}  ({result['response'].get('reason', '')})")
    print(f"OBLIGATIONS: {result['obligations']}")


def main():
    banner("TAMUCC ABAC - Policy Enforcement Point Demo")
    # clean log each run
    if os.path.exists("access_log.json"):
        os.remove("access_log.json")
    stub = StubDecisionSource(canned_path="canned_decisions.json")
    pep = PEP(decision_source=stub, log_path="access_log.json")
    print("PEP wired to StubDecisionSource (stands in for the PDP).")

    banner("Scenario 1: COSC faculty views COSC3310 grades")
    raw = {
        "subject": {"role": "faculty", "department": "cosc", "id": "F001"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "department": "cosc", "course": "COSC3310"}
    }
    show(raw, pep.handle(raw))

    banner("Scenario 2: Islander views their own grade (using aliases)")
    raw = {
        "user": {"role": "student", "id": "I12345678"},
        "operation": "view_grade",
        "target": {"type": "grade_record", "owner": "self"}
    }
    show(raw, pep.handle(raw))

    banner("Scenario 3: Student tries to modify grade (Deny + notify_admin)")
    raw = {
        "subject": {"role": "student", "id": "I99999999"},
        "action": "modify_grade",
        "resource": {"type": "grade_record"}
    }
    show(raw, pep.handle(raw))

    banner("Scenario 4: TA views roster (obligation: mask SSN/DOB)")
    raw = {
        "subject": {"role": "ta", "id": "I87654321"},
        "action": "view_roster",
        "resource": {"type": "course_roster", "course": "COSC4350"}
    }
    show(raw, pep.handle(raw))

    banner("Scenario 5: Visitor triggers Indeterminate (bonus handling)")
    raw = {
        "subject": {"badge_id": "VISITOR-001"},
        "action": "access_secure_lab",
        "resource": {"type": "lab", "building": "engineering"}
    }
    show(raw, pep.handle(raw))

    banner("Audit log written to access_log.json")
    with open("access_log.json") as f:
        log = json.load(f)
    print(f"Total records: {len(log)}")
    print(f"Enforced (Permit):  {sum(1 for r in log if r['enforced'])}")
    print(f"Denied:             {sum(1 for r in log if not r['enforced'])}")


if __name__ == "__main__":
    main()
