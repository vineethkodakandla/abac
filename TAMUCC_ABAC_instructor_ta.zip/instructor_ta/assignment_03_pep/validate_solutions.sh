#!/usr/bin/env bash
# Validate Assignment 03 reference solution against test suite.
# Must print "27 passed".
set -e
cd "$(dirname "$0")"

cp pep.py .pep_student_backup.py
cp pep_solution.py pep.py

rm -f access_log.json
python -m pytest -v --tb=short
rm -f access_log.json

mv .pep_student_backup.py pep.py
