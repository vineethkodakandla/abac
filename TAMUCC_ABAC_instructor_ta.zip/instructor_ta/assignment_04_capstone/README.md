# Assignment 04 — Capstone: Integrated Multi-Agent ABAC System

**Texas A&M University – Corpus Christi**
**COSC Department | Agent-Based Systems**

## What you're building

You've built three isolated agents in A01, A02, and A03. Each communicated
with the others only through data files. In this capstone you finally wire
them together into a single multi-agent system, driven by a shared interface
layer and 12 realistic TAMUCC scenarios.

See `Assignment_04_Worksheet.docx` for the full specification, grading
rubric, and reflection requirements.

## What you do

1. Drop your own `pap.py`, `pdp.py`, and `pep.py` into this directory.
2. Add ABC inheritance: `class PAP(PAPInterface)`, `class PDP(PDPInterface)`,
   `class PEP(PEPInterface)`. Import the ABCs from `abac_interfaces`.
3. Run `python main.py` — all 12 shipped scenarios must pass.
4. Run `pytest -v` — all integration tests must pass.
5. Author **two original TAMUCC scenarios** in `my_scenarios.json`.
6. Write a 1–2 page `REFLECTION.md`.

## What we provide

| File | Purpose |
|------|---------|
| `abac_interfaces.py` | Three ABCs — **do not modify** |
| `multi_agent_system.py` | Integration harness — composes the three agents |
| `scenarios.json` | 12 TAMUCC scenarios with expected outcomes |
| `policies.json` | Shared policy store |
| `test_integration.py` | Interface conformance + per-scenario + audit-trail tests |
| `main.py` | Runs every scenario and prints a PASS/FAIL summary |
| `Assignment_04_Worksheet.docx` | Full written spec + grading rubric |

## What you add

| File | Purpose |
|------|---------|
| `pap.py` | Your Assignment 01 code, extended with `PAPInterface` |
| `pdp.py` | Your Assignment 02 code, extended with `PDPInterface` |
| `pep.py` | Your Assignment 03 code, extended with `PEPInterface` |
| `my_scenarios.json` | Two new TAMUCC scenarios you author |
| `REFLECTION.md` | Required reflection document |
| `access_log.json` | Produced automatically when you run `main.py` |

## Setup

```bash
pip install pytest jsonschema
```

## Run

```bash
pytest -v
python main.py
```

## Submission

Zip file `Last-First-Capstone.zip` containing `pap.py`, `pdp.py`, `pep.py`,
`my_scenarios.json`, `REFLECTION.md`, and `access_log.json` → submit on
Blackboard.
