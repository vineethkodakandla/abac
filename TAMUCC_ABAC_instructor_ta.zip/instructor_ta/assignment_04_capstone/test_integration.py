"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone)
Integration Tests

These tests verify that your three agents - brought over from A1/A2/A3 and
extended to implement the ABCs in abac_interfaces.py - work together correctly.

Run with:  pytest -v
"""
import json
import os
import pytest

# Your submissions from previous assignments
from pap import PAP
from pdp import PDP
from pep import PEP

from abac_interfaces import PAPInterface, PDPInterface, PEPInterface
from multi_agent_system import MultiAgentSystem


@pytest.fixture
def system(tmp_path):
    # copy policies into a tmp dir so the test run doesn't mutate the committed file
    src = os.path.join(os.path.dirname(__file__), "policies.json")
    dst = tmp_path / "policies.json"
    dst.write_text(open(src).read())

    pap = PAP(policies_path=str(dst))
    pdp = PDP(policies_path=str(dst))
    log = str(tmp_path / "access_log.json")
    pep = PEP(decision_source=pdp, log_path=log)
    return MultiAgentSystem(pap=pap, pdp=pdp, pep=pep)


class TestInterfaceConformance:
    """Every agent must implement the matching ABC."""

    def test_pap_implements_interface(self, system):
        assert isinstance(system.pap, PAPInterface)

    def test_pdp_implements_interface(self, system):
        assert isinstance(system.pdp, PDPInterface)

    def test_pep_implements_interface(self, system):
        assert isinstance(system.pep, PEPInterface)


class TestScenarios:
    """Run every scenario end-to-end and check the expected outcome."""

    def _scenarios(self):
        path = os.path.join(os.path.dirname(__file__), "scenarios.json")
        with open(path) as f:
            return json.load(f)

    @pytest.mark.parametrize("scenario", [
        s for s in json.load(open(os.path.join(os.path.dirname(__file__),
                                                "scenarios.json")))
    ], ids=lambda s: s["id"])
    def test_scenario(self, system, scenario):
        result = system.run_scenario(scenario)
        assert result["decision"] == scenario["expected_decision"], (
            f"{scenario['id']} ({scenario['description']}): "
            f"expected {scenario['expected_decision']} but got {result['decision']}"
        )


class TestAuditTrail:

    def test_log_written_for_every_scenario(self, system, tmp_path):
        results = system.run_all(
            scenarios_path=os.path.join(os.path.dirname(__file__), "scenarios.json"))
        with open(system.pep.log_path) as f:
            log = json.load(f)
        assert len(log) == len(results)
