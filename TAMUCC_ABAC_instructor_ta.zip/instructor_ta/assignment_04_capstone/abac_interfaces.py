"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone)
Agent Interfaces

These ABCs define the interface each agent must expose for the integrated
multi-agent system to work. Your A1/A2/A3 classes already match these
shapes - you just need to (a) inherit from the ABC and (b) make sure
the method signatures line up.

DO NOT modify this file.
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any


class PAPInterface(ABC):
    """Policy Administration Point interface."""

    @abstractmethod
    def add_policy(self, policy: Dict[str, Any]) -> bool: ...

    @abstractmethod
    def delete_policy(self, policy_id: str) -> bool: ...

    @abstractmethod
    def get_applicable_policies(
        self, request_attrs: Dict[str, Any]) -> List[Dict[str, Any]]: ...


class PDPInterface(ABC):
    """Policy Decision Point interface."""

    @abstractmethod
    def evaluate(self, request: Dict[str, Any]) -> Dict[str, Any]: ...


class PEPInterface(ABC):
    """Policy Enforcement Point interface."""

    @abstractmethod
    def handle(self, raw_request: Dict[str, Any]) -> Dict[str, Any]: ...
