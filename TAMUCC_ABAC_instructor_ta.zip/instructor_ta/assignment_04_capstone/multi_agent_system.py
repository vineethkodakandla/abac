"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone)
Multi-Agent System Harness

Wires the three agents together:
  PEP ---(request)---> PDP ---(policies)---> PAP
       <--(decision)---    <--(policy set)---

In this capstone you will:
  1. Drop your Assignment 01 pap.py, Assignment 02 pdp.py, and Assignment 03 pep.py
     into this directory.
  2. Make each class inherit from the matching ABC in abac_interfaces.py.
  3. Use this harness (or write your own main.py) to run the scenarios from
     scenarios.json end-to-end.

DO NOT modify this file for the required tasks. You may extend it in the
reflection/stretch section if you wish.
"""
import json
from typing import Dict, Any, List


class MultiAgentSystem:
    """Composition root for the ABAC multi-agent system."""

    def __init__(self, pap, pdp, pep):
        self.pap = pap
        self.pdp = pdp
        self.pep = pep

    def run_scenario(self, scenario: Dict[str, Any]) -> Dict[str, Any]:
        """Run a single scenario end-to-end and return the PEP's result."""
        raw_request = scenario["request"]
        result = self.pep.handle(raw_request)
        return {
            "scenario_id": scenario.get("id"),
            "description": scenario.get("description"),
            "outcome": result["outcome"],
            "decision": result["response"].get("decision"),
            "matched_policy": result["response"].get("matched_policy"),
            "expected": scenario.get("expected_decision"),
            "pass": result["response"].get("decision") == scenario.get("expected_decision"),
        }

    def run_all(self, scenarios_path: str = "scenarios.json") -> List[Dict[str, Any]]:
        with open(scenarios_path) as f:
            scenarios = json.load(f)
        return [self.run_scenario(s) for s in scenarios]
