# Assignment 04 — Capstone Instructor Notes

## Learning objective alignment

The capstone exercises (1) integrating independently-built components, (2)
using ABCs as integration contracts, (3) end-to-end scenario testing, (4)
designing original test scenarios, and (5) architectural reflection.

## What students bring in

- Their own `pap.py` from A01
- Their own `pdp.py` from A02
- Their own `pep.py` from A03

## What we ship (instructor bundle contains reference versions of all of these)

- `abac_interfaces.py` — three ABCs (PAP/PDP/PEPInterface)
- `multi_agent_system.py` — composition harness
- `scenarios.json` — 12 TAMUCC scenarios with expected outcomes
- `policies.json` — shared policy store (same as A02 fixture)
- `test_integration.py` — 16 tests (3 interface conformance + 12 scenario + 1 audit trail)
- `main.py` — prints pass/fail summary for all 12 scenarios

The instructor bundle also includes reference `pap.py`, `pdp.py`, and
`pep.py` pre-extended with ABC inheritance, so you can run the full test
suite to verify everything integrates before distributing.

## Expected student stumbling points

1. **ABC inheritance subtleties.** Students forget to import the ABCs or
   mistype the base class name. `TestInterfaceConformance` catches this.

2. **Method signature drift.** If a student's `evaluate` returns something
   that doesn't match the expected shape, some scenarios pass and others
   fail seemingly at random. The fix is usually to point them at the
   decision response schema from A02.

3. **"It works with my PDP, but not with my PEP."** The most common
   integration bug. Students built their PEP against a stub and their PDP
   returns responses that are subtly different (e.g., missing `obligations`
   key). Have them run A02 tests + A03 tests independently first, then run
   A04.

4. **`NotApplicable` at scenario S08.** MATH faculty asking about COSC
   records returns `NotApplicable`, not `Deny` or `Permit`. Students who
   think of `Deny` as the "fall-through" confuse this. `NotApplicable`
   means **no policy matched** (PDP decision); the PEP then DENIES
   enforcement. The scenario compares against the PDP-level decision.

5. **Two authored scenarios are lazy.** Watch for trivial copy-paste
   scenarios. A good authored scenario exercises behavior not covered by
   the shipped 12. Rubric point 4 (15 pts) should reflect this.

## Running validation

```bash
cd instructor_ta/assignment_04_capstone/
bash validate_solutions.sh
# Expected: 16 passed
# Also: python main.py should print "Summary: 12/12 scenarios passed"
```

## Reflection grading criteria

Use this checklist to grade the reflection (20 pts total):

- [ ] **5 pts** — One architectural decision to change, with actual
  reasoning (not just "I'd use a database")
- [ ] **5 pts** — One real scenario their system can't handle, with a
  concrete extension (e.g., "temporal constraints would require adding a
  `time_window` field to the policy schema and extending `_matches_policy`
  to check it")
- [ ] **5 pts** — Data-contract vs code-dependency paragraph — should
  demonstrate understanding of WHY this decoupling matters (testing in
  isolation, parallel development, grading)
- [ ] **5 pts** — Description of the two authored scenarios in
  `my_scenarios.json` — what behavior they exercise and why it matters

## Integration quality (10 pts)

Manual check:

- Clean imports (no `from pap_solution import *`)
- ABC inheritance done correctly (`class PAP(PAPInterface):`)
- No duplicate code between their A01/A02/A03 versions and the capstone
  submission
- The code actually runs end-to-end without modifications to the harness

## Timing

Should be a 3–5 hour assignment if A01–A03 are already solid. Students who
produced broken earlier work will spend longer here fixing it. That's
acceptable — the capstone is a useful forcing function to clean up
earlier submissions.

## Original scenarios ideas (reference, for TAs answering questions)

Good student-authored scenarios often explore:

- Temporal constraints ("only during business hours" — not supported, but
  they can describe the needed extension)
- Cross-department escalation (a COSC faculty who is also a MATH chair)
- Obligation chains (a Permit with multiple obligations that must all
  succeed)
- Badge-based access with missing attributes
- Guest accounts with time-limited roles

Weak authored scenarios to push back on:

- Rename of an existing scenario with different IDs
- Any scenario that is a trivial edit of the fixture
- Scenarios that exercise only the framework, not the policy logic
