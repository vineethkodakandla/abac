"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone)
PEP reference (instructor validation copy).
DO_NOT_SHARE.
"""
import json
import os
from datetime import datetime, timezone
from typing import Dict, Any, List
from abac_interfaces import PEPInterface


class AccessDeniedError(Exception):
    pass


class PEP(PEPInterface):

    def __init__(self, decision_source, log_path: str = "access_log.json"):
        self.decision_source = decision_source
        self.log_path = log_path
        self.obligation_handlers = {
            "log": self._h_log,
            "notify_admin": self._h_notify,
            "mask_fields": self._h_mask,
            "require_reauth": self._h_reauth,
        }

    def build_decision_request(self, raw):
        subject = raw.get("subject") or raw.get("user") or {}
        action = raw.get("action") or raw.get("operation") or ""
        resource = raw.get("resource") or raw.get("target") or {}
        rid = raw.get("request_id") or f"REQ-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}"
        return {"request_id": rid, "subject": subject, "action": action, "resource": resource}

    def enforce(self, response):
        d = response.get("decision")
        if d == "Permit":
            return "ALLOWED"
        raise AccessDeniedError(f"{d}: {response.get('reason', '')}")

    def log_access_event(self, request, response, enforced):
        record = {"timestamp": datetime.now(timezone.utc).isoformat(),
                  "request": request, "response": response, "enforced": enforced}
        log = []
        if os.path.exists(self.log_path):
            with open(self.log_path) as f:
                log = json.load(f)
        log.append(record)
        with open(self.log_path, "w") as f:
            json.dump(log, f, indent=2)

    def apply_obligations(self, response, context):
        results = []
        for ob in response.get("obligations", []):
            h = self.obligation_handlers.get(ob.get("type"))
            if h:
                results.append(h(ob, context))
            else:
                results.append({"type": ob.get("type"), "status": "unknown"})
        return results

    def _h_log(self, ob, ctx): return {"type": "log", "status": "executed"}
    def _h_notify(self, ob, ctx): return {"type": "notify_admin", "status": "sent"}
    def _h_mask(self, ob, ctx): return {"type": "mask_fields", "status": "applied",
                                         "fields": ob.get("fields", [])}
    def _h_reauth(self, ob, ctx): return {"type": "require_reauth", "status": "prompted"}

    def handle(self, raw):
        request = self.build_decision_request(raw)
        response = self.decision_source.evaluate(request)
        try:
            outcome = self.enforce(response)
            enforced = True
        except AccessDeniedError:
            outcome = "DENIED"
            enforced = False
        obs = self.apply_obligations(response, {"request": request})
        self.log_access_event(request, response, enforced)
        return {"outcome": outcome, "response": response, "obligations": obs}
