#!/usr/bin/env bash
# Validate Assignment 04 reference agents against test suite.
# Must print "16 passed".
set -e
cd "$(dirname "$0")"

rm -f access_log.json
python -m pytest -v --tb=short
rm -f access_log.json
