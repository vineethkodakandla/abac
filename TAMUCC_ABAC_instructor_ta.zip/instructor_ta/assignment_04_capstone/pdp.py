"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone)
PDP reference (instructor validation copy).
DO_NOT_SHARE.
"""
import json
from typing import Dict, Any, List, Optional
from abac_interfaces import PDPInterface


class PDP(PDPInterface):

    def __init__(self, policies_path: str = "policies.json",
                 combining_algorithm: str = "first_applicable"):
        self.policies_path = policies_path
        self.combining_algorithm = combining_algorithm
        with open(policies_path) as f:
            self.policies = json.load(f)

    def _attrs_match(self, policy_attrs, request_attrs):
        for k, v in policy_attrs.items():
            if k not in request_attrs or request_attrs[k] != v:
                return False
        return True

    def _matches_policy(self, policy, request):
        if policy["action"] != "*" and policy["action"] != request.get("action"):
            return False
        if not self._attrs_match(policy["subject"], request.get("subject", {})):
            return False
        if not self._attrs_match(policy["resource"], request.get("resource", {})):
            return False
        return True

    def _build_reason(self, policy, decision):
        if policy is None:
            return f"Decision={decision}: no applicable policy found."
        return (f"Decision={decision} because policy {policy['policy_id']} "
                f"('{policy['description']}') matched with priority {policy['priority']}.")

    def _first_applicable(self, applicable, request):
        if not applicable:
            return {"request_id": request.get("request_id"),
                    "decision": "NotApplicable", "matched_policy": None,
                    "reason": self._build_reason(None, "NotApplicable"),
                    "obligations": []}
        winner = sorted(applicable, key=lambda p: p["priority"])[0]
        return {"request_id": request.get("request_id"),
                "decision": winner["effect"],
                "matched_policy": winner["policy_id"],
                "reason": self._build_reason(winner, winner["effect"]),
                "obligations": winner.get("obligations", [])}

    def evaluate(self, request):
        applicable = [p for p in self.policies if self._matches_policy(p, request)]
        return self._first_applicable(applicable, request)
