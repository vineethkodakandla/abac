"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone)
PAP reference (instructor validation copy; for student use, this file is
replaced by the student's own Assignment 01 submission).
DO_NOT_SHARE.
"""
import json
import os
from typing import List, Dict, Any
from abac_interfaces import PAPInterface


class PAP(PAPInterface):
    VALID_EFFECTS = {"Permit", "Deny"}
    REQUIRED_POLICY_FIELDS = {
        "policy_id", "description", "effect",
        "subject", "action", "resource", "priority"
    }

    def __init__(self, policies_path: str = "policies.json"):
        self.policies_path = policies_path
        self.policies: List[Dict[str, Any]] = []
        if os.path.exists(policies_path):
            with open(policies_path) as f:
                self.policies = json.load(f)

    def _save(self):
        with open(self.policies_path, "w") as f:
            json.dump(self.policies, f, indent=2)

    def add_policy(self, policy):
        if not isinstance(policy, dict):
            return False
        if not self.REQUIRED_POLICY_FIELDS.issubset(policy.keys()):
            return False
        if policy["effect"] not in self.VALID_EFFECTS:
            return False
        if not isinstance(policy["priority"], int):
            return False
        if not isinstance(policy["subject"], dict):
            return False
        if not isinstance(policy["resource"], dict):
            return False
        if not isinstance(policy["action"], str) or not policy["action"]:
            return False
        if any(p["policy_id"] == policy["policy_id"] for p in self.policies):
            return False
        self.policies.append(policy)
        self._save()
        return True

    def delete_policy(self, policy_id):
        for i, p in enumerate(self.policies):
            if p["policy_id"] == policy_id:
                del self.policies[i]
                self._save()
                return True
        return False

    def get_applicable_policies(self, request_attrs):
        req_subject = request_attrs.get("subject", {})
        req_action = request_attrs.get("action")
        req_resource = request_attrs.get("resource", {})
        out = []
        for p in self.policies:
            if p["action"] != "*" and p["action"] != req_action:
                continue
            conflict = False
            for k, v in p["subject"].items():
                if k in req_subject and req_subject[k] != v:
                    conflict = True
                    break
            if conflict:
                continue
            for k, v in p["resource"].items():
                if k in req_resource and req_resource[k] != v:
                    conflict = True
                    break
            if conflict:
                continue
            out.append(p)
        return out
