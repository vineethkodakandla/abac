"""
TAMUCC Agent-Based Systems | Assignment 04 (Capstone) Demo

Runs all 12 scenarios through the full PEP -> PDP -> PAP stack and prints a
pass/fail summary.

Before running: make sure you have copied your A1 pap.py, A2 pdp.py, and
A3 pep.py into this directory, and that each class inherits from the
matching ABC in abac_interfaces.py.
"""
import os
from pap import PAP
from pdp import PDP
from pep import PEP
from multi_agent_system import MultiAgentSystem


def banner(title):
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)


def main():
    banner("TAMUCC ABAC - Multi-Agent System End-to-End")

    # Clean up old log
    if os.path.exists("access_log.json"):
        os.remove("access_log.json")

    pap = PAP(policies_path="policies.json")
    pdp = PDP(policies_path="policies.json")
    pep = PEP(decision_source=pdp, log_path="access_log.json")
    system = MultiAgentSystem(pap=pap, pdp=pdp, pep=pep)

    print(f"PAP loaded with {len(pap.policies)} policies")
    print(f"PDP using '{pdp.combining_algorithm}' combining algorithm")
    print(f"PEP wired to PDP, audit log -> access_log.json")

    banner("Running scenarios.json")
    results = system.run_all(scenarios_path="scenarios.json")

    header = f"{'ID':5} {'EXPECTED':16} {'ACTUAL':16} {'PASS':6}  DESCRIPTION"
    print(header)
    print("-" * 100)
    passed = 0
    for r in results:
        status = "PASS" if r["pass"] else "FAIL"
        if r["pass"]:
            passed += 1
        print(f"{r['scenario_id']:5} {r['expected']:16} "
              f"{str(r['decision']):16} {status:6}  {r['description']}")

    banner(f"Summary: {passed}/{len(results)} scenarios passed")


if __name__ == "__main__":
    main()
