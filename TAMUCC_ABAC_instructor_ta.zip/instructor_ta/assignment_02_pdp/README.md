# Assignment 02 — Policy Decision Point (PDP)

**Texas A&M University – Corpus Christi**
**COSC Department | Agent-Based Systems**

## What you're building

The Policy Decision Point — the agent that takes a decision request,
consults the policy store, applies a combining algorithm, and returns
a decision response. You implement five methods in `pdp.py` (four required,
one bonus).

See `Assignment_02_Worksheet.docx` for the full specification.

## Important: This assignment is independent of Assignment 01

Your PDP loads `policies.json` **directly** — it does not import any PAP.
The contract between the two agents is the JSON file. You can complete
A02 even if your A01 is unfinished. A hand-authored `policies.json` covering
edge cases ships with this assignment.

## Files in this directory

| File | Purpose |
|------|---------|
| `pdp.py` | Student template with TODO blocks — edit this |
| `policies.json` | Hand-authored fixture covering TAMUCC scenarios + edge cases |
| `decision_response.schema.json` | Output contract for the PDP → PEP handoff |
| `test_pdp.py` | Task-grouped pytest suite — 30 test cases |
| `test_output_contract.py` | Validates that every evaluate() response matches the schema |
| `main.py` | TAMUCC-themed demo |
| `Assignment_02_Worksheet.docx` | Full written spec + grading rubric |

## Setup

```bash
pip install pytest jsonschema
```

## Run

```bash
pytest -v
python main.py
```

## Submission

Zip file `Last-First-A02.zip` containing `pdp.py` → submit on Blackboard.
