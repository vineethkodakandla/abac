# Assignment 02 — Instructor Notes (PDP)

## Learning objective alignment

This assignment is the intellectual heart of the series. It covers (1)
exact matching with hierarchical attribute dicts, (2) combining algorithms,
(3) priority-based conflict resolution, and (4) the structured output
contract that feeds the PEP.

## Method 1 decoupling

**The PDP does NOT import the PAP.** This is the key change from earlier
versions of the assignment. The PDP loads `policies.json` directly via
`json.load()`. The `policies.json` shipped with this assignment is
hand-authored specifically as a test fixture — it is NOT a PAP output and
does not depend on any Assignment 01 code.

Students can complete this assignment even if their A01 submission is
incomplete or broken. This is by design.

## Reference solution

`pdp_solution.py` — drop-in complete implementation including the bonus
`_deny_overrides`. Marked `DO_NOT_SHARE`. All 33 tests pass.

## Expected student stumbling points

1. **Priority direction.** Lower number = higher precedence. This is
   counterintuitive. Emphasize with a worked example in lecture: "priority
   1 is like a VIP pass — it wins over priority 100."

2. **Empty `policy["subject"]` means wildcard.** Several students
   implement `_attrs_match` as "both must be empty to match" instead of
   "empty policy matches anything." `test_empty_policy_matches_anything`
   catches this.

3. **The `"*"` action.** Easy to miss the special case. Tests exercise it
   via `test_wildcard_action`.

4. **Response schema.** Students sometimes return only
   `{"decision": "Permit"}` rather than the full response with `request_id`,
   `matched_policy`, `reason`, and `obligations`. The output contract tests
   catch this.

5. **Priority sorting direction.** Students sometimes sort descending
   (thinking "higher priority wins"). The `test_chair_can_modify_grades_priority_wins`
   test exercises priority 5 vs priority 100 in the same policy set.

## Running validation

```bash
cd instructor_ta/assignment_02_pdp/
bash validate_solutions.sh
# Expected: 33 passed
```

## Policy fixture notes

The shipped `policies.json` has 9 policies carefully chosen to exercise:

- Normal Permit (P001 COSC faculty, P002 Islander, P003 TA, etc.)
- Default-Deny behavior (P004 modify_grade)
- Priority-wins-over-default-deny (P006 chair)
- Priority-based deny (P008 sealed records — priority 1, beats P001)
- Cross-department rejection (P001 cosc vs P007 math)
- Non-role-based subject (P009 visitor badge_id)

If you modify `policies.json`, re-run the test suite — several scenarios
depend on specific priority values.

## Common manual-review items

- Is `_build_reason` producing readable English or just concatenating fields?
- Did they implement the `evaluate()` wrapper correctly, dispatching on
  `combining_algorithm`?
- Is the response shape consistent across all three decision types?

## Grading tip

`TestTask3FirstApplicable::test_sealed_record_denied` is the diagnostic
test for priority semantics. Students who get priority backwards will fail
this one specifically.
