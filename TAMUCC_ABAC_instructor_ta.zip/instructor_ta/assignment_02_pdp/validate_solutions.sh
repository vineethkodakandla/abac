#!/usr/bin/env bash
# Validate Assignment 02 reference solution against test suite.
# Must print "33 passed".
set -e
cd "$(dirname "$0")"

cp pdp.py .pdp_student_backup.py
cp pdp_solution.py pdp.py

python -m pytest -v --tb=short

mv .pdp_student_backup.py pdp.py
