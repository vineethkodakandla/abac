"""
TAMUCC Agent-Based Systems | Assignment 02
Policy Decision Point (PDP) - INSTRUCTOR REFERENCE SOLUTION
DO_NOT_SHARE with students.

IMPORTANT: This PDP does NOT import any PAP. It reads policies.json directly.
The "contract" between the two agents is the JSON file, not a Python class.
"""
import json
import os
from typing import List, Dict, Any, Optional, Callable


class PDP:
    """
    Policy Decision Point.

    Receives a decision request, consults the policy store (policies.json),
    applies a combining algorithm, and returns a decision response.
    """

    def __init__(self, policies_path: str = "policies.json",
                 combining_algorithm: str = "first_applicable"):
        self.policies_path = policies_path
        self.combining_algorithm = combining_algorithm
        with open(policies_path, "r") as f:
            self.policies = json.load(f)

    # ---------- TASK 1 ----------
    def _attrs_match(self, policy_attrs: Dict[str, Any],
                     request_attrs: Dict[str, Any]) -> bool:
        """
        Every key in policy_attrs must be present in request_attrs AND have the same value.
        Extra keys in request_attrs are fine.
        Empty policy_attrs means 'matches anything'.
        """
        for k, v in policy_attrs.items():
            if k not in request_attrs:
                return False
            if request_attrs[k] != v:
                return False
        return True

    # ---------- TASK 2 ----------
    def _matches_policy(self, policy: Dict[str, Any],
                        request: Dict[str, Any]) -> bool:
        """A policy matches the request iff subject AND action AND resource all match."""
        if policy["action"] != "*" and policy["action"] != request.get("action"):
            return False
        if not self._attrs_match(policy["subject"], request.get("subject", {})):
            return False
        if not self._attrs_match(policy["resource"], request.get("resource", {})):
            return False
        return True

    # ---------- TASK 3 ----------
    def _apply_combining_algorithm(self, applicable: List[Dict[str, Any]],
                                   request: Dict[str, Any]) -> Dict[str, Any]:
        """
        First-Applicable: sort by priority ascending (lower = higher precedence)
        then return decision from the first matching policy. If none applicable,
        return NotApplicable (default deny behavior is a PEP concern, not PDP).
        """
        if not applicable:
            return {
                "request_id": request.get("request_id"),
                "decision": "NotApplicable",
                "matched_policy": None,
                "reason": self._build_reason(None, "NotApplicable"),
                "obligations": []
            }
        sorted_policies = sorted(applicable, key=lambda p: p["priority"])
        winner = sorted_policies[0]
        return {
            "request_id": request.get("request_id"),
            "decision": winner["effect"],
            "matched_policy": winner["policy_id"],
            "reason": self._build_reason(winner, winner["effect"]),
            "obligations": winner.get("obligations", [])
        }

    # ---------- TASK 4 ----------
    def _build_reason(self, policy: Optional[Dict[str, Any]],
                      decision: str) -> str:
        """Human-readable audit justification."""
        if policy is None:
            return f"Decision={decision}: no applicable policy found."
        return (f"Decision={decision} because policy {policy['policy_id']} "
                f"('{policy['description']}') matched with priority {policy['priority']}.")

    # ---------- BONUS TASK ----------
    def _deny_overrides(self, applicable: List[Dict[str, Any]],
                        request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deny-Overrides: if any applicable policy says Deny, the final decision is Deny.
        Otherwise Permit (if any Permit exists), else NotApplicable.
        """
        if not applicable:
            return {
                "request_id": request.get("request_id"),
                "decision": "NotApplicable",
                "matched_policy": None,
                "reason": self._build_reason(None, "NotApplicable"),
                "obligations": []
            }
        denies = [p for p in applicable if p["effect"] == "Deny"]
        if denies:
            winner = sorted(denies, key=lambda p: p["priority"])[0]
            return {
                "request_id": request.get("request_id"),
                "decision": "Deny",
                "matched_policy": winner["policy_id"],
                "reason": self._build_reason(winner, "Deny"),
                "obligations": winner.get("obligations", [])
            }
        permits = [p for p in applicable if p["effect"] == "Permit"]
        if permits:
            winner = sorted(permits, key=lambda p: p["priority"])[0]
            return {
                "request_id": request.get("request_id"),
                "decision": "Permit",
                "matched_policy": winner["policy_id"],
                "reason": self._build_reason(winner, "Permit"),
                "obligations": winner.get("obligations", [])
            }
        return {
            "request_id": request.get("request_id"),
            "decision": "NotApplicable",
            "matched_policy": None,
            "reason": self._build_reason(None, "NotApplicable"),
            "obligations": []
        }

    # ---------- Public API ----------
    def evaluate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Main entry point: takes a request, returns a decision response."""
        applicable = [p for p in self.policies if self._matches_policy(p, request)]
        if self.combining_algorithm == "deny_overrides":
            return self._deny_overrides(applicable, request)
        return self._apply_combining_algorithm(applicable, request)
