"""
TAMUCC Agent-Based Systems | Assignment 02
Policy Decision Point (PDP) - Student Template

Your job: implement the five methods marked with TODO (4 required + 1 bonus).

IMPORTANT: This PDP reads policies.json DIRECTLY - no PAP import, no PAP class.
The contract between the two agents is the JSON file itself. You'll see how
everything reconnects in the capstone (Assignment 04).

Run tests with:  pytest -v
Run the demo:    python main.py
"""
import json
import os
from typing import List, Dict, Any, Optional


class PDP:
    """
    Policy Decision Point.

    Receives a decision request, consults the policy store (policies.json),
    applies a combining algorithm, and returns a decision response.
    """

    def __init__(self, policies_path: str = "policies.json",
                 combining_algorithm: str = "first_applicable"):
        self.policies_path = policies_path
        self.combining_algorithm = combining_algorithm
        with open(policies_path, "r") as f:
            self.policies = json.load(f)

    # ---------- TASK 1 ----------
    def _attrs_match(self, policy_attrs: Dict[str, Any],
                     request_attrs: Dict[str, Any]) -> bool:
        """
        Attribute-level match.

        Return True iff every key in policy_attrs is present in request_attrs
        AND has the same value. Extra keys in request_attrs are fine.
        Empty policy_attrs matches anything (returns True).

        Examples:
            policy={"role": "faculty"}, request={"role": "faculty", "id": "F1"} -> True
            policy={"role": "faculty"}, request={"role": "student"}             -> False
            policy={"role": "faculty", "dept": "cosc"}, request={"role": "faculty"} -> False
            policy={}, request={"role": "anything"}                             -> True
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 2 ----------
    def _matches_policy(self, policy: Dict[str, Any],
                        request: Dict[str, Any]) -> bool:
        """
        Policy-level match.

        A policy matches the request iff:
          - policy["action"] equals request["action"] (or policy action is "*"), AND
          - subject attributes match (use _attrs_match), AND
          - resource attributes match (use _attrs_match).
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 3 ----------
    def _apply_combining_algorithm(self, applicable: List[Dict[str, Any]],
                                   request: Dict[str, Any]) -> Dict[str, Any]:
        """
        First-Applicable combining algorithm.

        1. Sort `applicable` by priority ASCENDING (lower = higher precedence).
        2. If empty, return a NotApplicable response.
        3. Otherwise, take the first policy and return its effect as the decision.

        The response dict MUST have these keys:
            request_id, decision, matched_policy, reason, obligations
        - decision: "Permit" / "Deny" / "NotApplicable"
        - matched_policy: the policy_id string, or None if NotApplicable
        - reason: use self._build_reason(...)
        - obligations: policy.get("obligations", []) or []
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 4 ----------
    def _build_reason(self, policy: Optional[Dict[str, Any]],
                      decision: str) -> str:
        """
        Human-readable audit justification.

        If policy is None: "Decision=<X>: no applicable policy found."
        Otherwise: "Decision=<X> because policy <id> ('<desc>') matched with priority <n>."
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- BONUS TASK ----------
    def _deny_overrides(self, applicable: List[Dict[str, Any]],
                        request: Dict[str, Any]) -> Dict[str, Any]:
        """
        BONUS: Deny-Overrides combining algorithm.

        - If ANY applicable policy has effect=Deny, return Deny (winner = lowest priority Deny).
        - Else if any Permit exists, return Permit (winner = lowest priority Permit).
        - Else return NotApplicable.
        """
        # TODO: implement (bonus, optional)
        raise NotImplementedError

    # ---------- Public API (do not modify) ----------
    def evaluate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Main entry point. Given a request, return a decision response."""
        applicable = [p for p in self.policies if self._matches_policy(p, request)]
        if self.combining_algorithm == "deny_overrides":
            return self._deny_overrides(applicable, request)
        return self._apply_combining_algorithm(applicable, request)
