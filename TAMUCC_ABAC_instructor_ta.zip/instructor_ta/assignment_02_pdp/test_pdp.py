"""
TAMUCC Agent-Based Systems | Assignment 02 Tests
Policy Decision Point (PDP)

Tests grouped by task class. The policies.json fixture used here is
hand-authored for coverage - it is NOT a PAP output and does not assume
any Assignment 01 code.

Run with:  pytest -v
"""
import os
import pytest
from pdp import PDP


@pytest.fixture
def pdp():
    path = os.path.join(os.path.dirname(__file__), "policies.json")
    return PDP(policies_path=path)


@pytest.fixture
def pdp_deny():
    path = os.path.join(os.path.dirname(__file__), "policies.json")
    return PDP(policies_path=path, combining_algorithm="deny_overrides")


# =====================================================================
# TASK 1: _attrs_match
# =====================================================================
class TestTask1AttrsMatch:

    def test_exact_match(self, pdp):
        assert pdp._attrs_match({"role": "faculty"}, {"role": "faculty"}) is True

    def test_request_has_extra_attrs(self, pdp):
        assert pdp._attrs_match(
            {"role": "faculty"},
            {"role": "faculty", "id": "F001", "department": "cosc"}
        ) is True

    def test_mismatch_value(self, pdp):
        assert pdp._attrs_match(
            {"role": "faculty"}, {"role": "student"}
        ) is False

    def test_missing_key_in_request(self, pdp):
        assert pdp._attrs_match(
            {"role": "faculty", "department": "cosc"},
            {"role": "faculty"}
        ) is False

    def test_empty_policy_matches_anything(self, pdp):
        assert pdp._attrs_match({}, {"role": "anyone"}) is True
        assert pdp._attrs_match({}, {}) is True

    def test_both_empty(self, pdp):
        assert pdp._attrs_match({}, {}) is True

    def test_multi_key_match(self, pdp):
        assert pdp._attrs_match(
            {"role": "faculty", "department": "cosc"},
            {"role": "faculty", "department": "cosc", "id": "F001"}
        ) is True

    def test_boolean_value_match(self, pdp):
        assert pdp._attrs_match({"sealed": True}, {"sealed": True}) is True
        assert pdp._attrs_match({"sealed": True}, {"sealed": False}) is False


# =====================================================================
# TASK 2: _matches_policy
# =====================================================================
class TestTask2MatchesPolicy:

    def test_full_match(self, pdp):
        policy = pdp.policies[0]  # P001
        req = {
            "subject": {"role": "faculty", "department": "cosc", "id": "F001"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        assert pdp._matches_policy(policy, req) is True

    def test_action_mismatch(self, pdp):
        policy = pdp.policies[0]  # P001 is view_grade
        req = {
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "delete_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        assert pdp._matches_policy(policy, req) is False

    def test_subject_mismatch(self, pdp):
        policy = pdp.policies[0]  # requires faculty
        req = {
            "subject": {"role": "student"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        assert pdp._matches_policy(policy, req) is False

    def test_resource_mismatch(self, pdp):
        policy = pdp.policies[0]  # cosc dept resource
        req = {
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "biol"}
        }
        assert pdp._matches_policy(policy, req) is False

    def test_wildcard_action(self, pdp):
        wildcard_policy = {
            "policy_id": "WILD", "description": "wildcard",
            "effect": "Permit", "subject": {"role": "admin"},
            "action": "*", "resource": {}, "priority": 1
        }
        req = {"subject": {"role": "admin"}, "action": "anything", "resource": {}}
        assert pdp._matches_policy(wildcard_policy, req) is True

    def test_empty_subject_policy_matches_any(self, pdp):
        p004 = next(p for p in pdp.policies if p["policy_id"] == "P004")
        req = {
            "subject": {"role": "anyone"},
            "action": "modify_grade",
            "resource": {"type": "grade_record"}
        }
        assert pdp._matches_policy(p004, req) is True


# =====================================================================
# TASK 3: _apply_combining_algorithm (First-Applicable)
# =====================================================================
class TestTask3FirstApplicable:

    def test_cosc_faculty_gets_permit(self, pdp):
        req = {
            "request_id": "R1",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        response = pdp.evaluate(req)
        assert response["decision"] == "Permit"
        assert response["matched_policy"] == "P001"
        assert response["request_id"] == "R1"

    def test_islander_views_own_grade(self, pdp):
        req = {
            "request_id": "R2",
            "subject": {"role": "student", "id": "I12345678"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "owner": "self"}
        }
        response = pdp.evaluate(req)
        assert response["decision"] == "Permit"
        assert response["matched_policy"] == "P002"

    def test_anyone_cannot_modify_grade_default_deny(self, pdp):
        req = {
            "request_id": "R3",
            "subject": {"role": "student"},
            "action": "modify_grade",
            "resource": {"type": "grade_record"}
        }
        response = pdp.evaluate(req)
        assert response["decision"] == "Deny"
        assert response["matched_policy"] == "P004"

    def test_chair_can_modify_grades_priority_wins(self, pdp):
        # P006 (priority 5) should win over P004 (priority 100)
        req = {
            "request_id": "R4",
            "subject": {"role": "chair", "department": "cosc"},
            "action": "modify_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        response = pdp.evaluate(req)
        assert response["decision"] == "Permit"
        assert response["matched_policy"] == "P006"

    def test_sealed_record_denied(self, pdp):
        # P008 (priority 1, deny) should beat P001 (priority 10, permit)
        req = {
            "request_id": "R5",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc", "sealed": True}
        }
        response = pdp.evaluate(req)
        assert response["decision"] == "Deny"
        assert response["matched_policy"] == "P008"

    def test_not_applicable(self, pdp):
        req = {
            "request_id": "R6",
            "subject": {"role": "janitor"},
            "action": "delete_building",
            "resource": {"type": "campus"}
        }
        response = pdp.evaluate(req)
        assert response["decision"] == "NotApplicable"
        assert response["matched_policy"] is None

    def test_response_has_all_required_fields(self, pdp):
        req = {
            "request_id": "R7",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        response = pdp.evaluate(req)
        for key in ["request_id", "decision", "matched_policy", "reason", "obligations"]:
            assert key in response

    def test_obligations_is_list(self, pdp):
        req = {
            "request_id": "R8",
            "subject": {"role": "student"},
            "action": "modify_grade",
            "resource": {"type": "grade_record"}
        }
        response = pdp.evaluate(req)
        assert isinstance(response["obligations"], list)


# =====================================================================
# TASK 4: _build_reason
# =====================================================================
class TestTask4BuildReason:

    def test_reason_with_policy(self, pdp):
        policy = pdp.policies[0]  # P001
        reason = pdp._build_reason(policy, "Permit")
        assert "P001" in reason
        assert "Permit" in reason
        assert "10" in reason  # priority

    def test_reason_with_no_policy(self, pdp):
        reason = pdp._build_reason(None, "NotApplicable")
        assert "NotApplicable" in reason
        assert "no applicable policy" in reason.lower() or "none" in reason.lower()

    def test_reason_is_string(self, pdp):
        reason = pdp._build_reason(pdp.policies[0], "Permit")
        assert isinstance(reason, str)
        assert len(reason) > 0

    def test_reason_included_in_response(self, pdp):
        req = {
            "request_id": "R_REASON",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        resp = pdp.evaluate(req)
        assert "P001" in resp["reason"]


# =====================================================================
# BONUS: _deny_overrides
# =====================================================================
class TestBonusDenyOverrides:

    def test_deny_wins_over_permit(self, pdp_deny):
        # Request that matches both a Deny (P008, sealed) and a Permit (P001)
        req = {
            "request_id": "DR1",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc", "sealed": True}
        }
        response = pdp_deny.evaluate(req)
        assert response["decision"] == "Deny"

    def test_only_permit_applicable(self, pdp_deny):
        req = {
            "request_id": "DR2",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        response = pdp_deny.evaluate(req)
        assert response["decision"] == "Permit"

    def test_no_applicable(self, pdp_deny):
        req = {
            "request_id": "DR3",
            "subject": {"role": "ghost"},
            "action": "haunt",
            "resource": {"type": "building"}
        }
        response = pdp_deny.evaluate(req)
        assert response["decision"] == "NotApplicable"

    def test_priority_within_deny(self, pdp_deny):
        # When multiple denies apply, lowest-priority Deny wins.
        # P004 (pri=100) and P008 (pri=1) both deny - P008 should win.
        req = {
            "request_id": "DR4",
            "subject": {"role": "student"},
            "action": "modify_grade",
            "resource": {"type": "grade_record", "sealed": True}
        }
        response = pdp_deny.evaluate(req)
        # P004 matches (modify_grade, grade_record), P008 matches (view_grade -> wait no)
        # P008 is for view_grade so it does not match modify_grade
        # so only P004 matches
        assert response["decision"] == "Deny"
        assert response["matched_policy"] == "P004"
