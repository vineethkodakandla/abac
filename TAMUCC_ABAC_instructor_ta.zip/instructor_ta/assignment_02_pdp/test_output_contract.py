"""
TAMUCC Agent-Based Systems | Assignment 02
Output Contract Test

Your PDP's decision response is the INPUT to the PEP (Assignment 03).
Every response your PDP produces must validate against decision_response.schema.json.
"""
import json
import os
import pytest
from jsonschema import validate
from pdp import PDP


@pytest.fixture
def schema():
    path = os.path.join(os.path.dirname(__file__), "decision_response.schema.json")
    with open(path) as f:
        return json.load(f)


@pytest.fixture
def pdp():
    path = os.path.join(os.path.dirname(__file__), "policies.json")
    return PDP(policies_path=path)


class TestOutputContract:

    def test_permit_response_schema(self, pdp, schema):
        req = {
            "request_id": "CT1",
            "subject": {"role": "faculty", "department": "cosc"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        response = pdp.evaluate(req)
        validate(instance=response, schema=schema)

    def test_deny_response_schema(self, pdp, schema):
        req = {
            "request_id": "CT2",
            "subject": {"role": "student"},
            "action": "modify_grade",
            "resource": {"type": "grade_record"}
        }
        response = pdp.evaluate(req)
        validate(instance=response, schema=schema)

    def test_not_applicable_response_schema(self, pdp, schema):
        req = {
            "request_id": "CT3",
            "subject": {"role": "ghost"},
            "action": "haunt",
            "resource": {"type": "building"}
        }
        response = pdp.evaluate(req)
        validate(instance=response, schema=schema)
