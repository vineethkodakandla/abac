"""
TAMUCC Agent-Based Systems | Assignment 02 Demo
Policy Decision Point (PDP)

Walks through several TAMUCC scenarios showing how the PDP turns
a request into a decision response.
"""
import json
from pdp import PDP


def banner(title):
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)


def show_response(req, resp):
    print(f"REQUEST:  {json.dumps(req, indent=2)}")
    print(f"DECISION: {resp['decision']}")
    print(f"POLICY:   {resp['matched_policy']}")
    print(f"REASON:   {resp['reason']}")


def main():
    banner("TAMUCC ABAC - Policy Decision Point Demo")
    pdp = PDP(policies_path="policies.json")
    print(f"Loaded {len(pdp.policies)} policies (First-Applicable algorithm)")

    banner("Scenario 1: COSC faculty views COSC grade record")
    req = {
        "request_id": "DEMO1",
        "subject": {"role": "faculty", "department": "cosc", "id": "F001"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "department": "cosc", "course": "COSC3310"}
    }
    show_response(req, pdp.evaluate(req))

    banner("Scenario 2: Islander views their own grade")
    req = {
        "request_id": "DEMO2",
        "subject": {"role": "student", "id": "I12345678"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "owner": "self"}
    }
    show_response(req, pdp.evaluate(req))

    banner("Scenario 3: Student tries to modify a grade (should Deny)")
    req = {
        "request_id": "DEMO3",
        "subject": {"role": "student", "id": "I12345678"},
        "action": "modify_grade",
        "resource": {"type": "grade_record"}
    }
    show_response(req, pdp.evaluate(req))

    banner("Scenario 4: Chair modifies a grade (priority wins)")
    req = {
        "request_id": "DEMO4",
        "subject": {"role": "chair", "department": "cosc"},
        "action": "modify_grade",
        "resource": {"type": "grade_record", "department": "cosc"}
    }
    show_response(req, pdp.evaluate(req))

    banner("Scenario 5: Sealed record - Deny wins via priority")
    req = {
        "request_id": "DEMO5",
        "subject": {"role": "faculty", "department": "cosc"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "department": "cosc", "sealed": True}
    }
    show_response(req, pdp.evaluate(req))

    banner("Scenario 6: No applicable policy")
    req = {
        "request_id": "DEMO6",
        "subject": {"role": "janitor"},
        "action": "burn_building",
        "resource": {"type": "campus"}
    }
    show_response(req, pdp.evaluate(req))

    banner("Scenario 7: Deny-Overrides algorithm")
    pdp_d = PDP(policies_path="policies.json", combining_algorithm="deny_overrides")
    req = {
        "request_id": "DEMO7",
        "subject": {"role": "faculty", "department": "cosc"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "department": "cosc", "sealed": True}
    }
    try:
        show_response(req, pdp_d.evaluate(req))
    except NotImplementedError:
        print("(deny_overrides not implemented - bonus task)")


if __name__ == "__main__":
    main()
