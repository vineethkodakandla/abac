"""
TAMUCC Agent-Based Systems | Assignment 01
Output Contract Test

The policies.json your PAP produces is the INPUT to the PDP (Assignment 02).
This is the "contract" between the two agents. Your A1 submission must produce
a file that validates against policies.schema.json - otherwise the PDP won't
be able to read it.

Run this test AFTER you've made whatever changes your workflow produces.
"""
import json
import os
import shutil
import pytest
from jsonschema import validate, ValidationError
from pap import PAP


@pytest.fixture
def schema():
    path = os.path.join(os.path.dirname(__file__), "policies.schema.json")
    with open(path) as f:
        return json.load(f)


@pytest.fixture
def fresh_pap(tmp_path):
    src = os.path.join(os.path.dirname(__file__), "policies.json")
    dst = tmp_path / "policies.json"
    shutil.copy(src, dst)
    return PAP(policies_path=str(dst))


class TestOutputContract:

    def test_seed_file_matches_schema(self, schema):
        path = os.path.join(os.path.dirname(__file__), "policies.json")
        with open(path) as f:
            data = json.load(f)
        validate(instance=data, schema=schema)

    def test_after_add_still_valid(self, fresh_pap, schema):
        fresh_pap.add_policy({
            "policy_id": "CONTRACT_ADD",
            "description": "added via PAP",
            "effect": "Permit",
            "subject": {"role": "faculty"},
            "action": "view_grade",
            "resource": {"type": "grade_record"},
            "priority": 50
        })
        with open(fresh_pap.policies_path) as f:
            data = json.load(f)
        validate(instance=data, schema=schema)

    def test_after_delete_still_valid(self, fresh_pap, schema):
        fresh_pap.delete_policy("P001")
        with open(fresh_pap.policies_path) as f:
            data = json.load(f)
        validate(instance=data, schema=schema)
