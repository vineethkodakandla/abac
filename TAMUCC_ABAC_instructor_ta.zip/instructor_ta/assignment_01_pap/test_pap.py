"""
TAMUCC Agent-Based Systems | Assignment 01 Tests
Policy Administration Point (PAP)

Tests are grouped by task class. Each class corresponds to one TODO
in pap.py. Run with:  pytest -v
"""
import json
import os
import shutil
import pytest
from pap import PAP


@pytest.fixture
def tmp_policies(tmp_path):
    """Copy the seed policies.json into a temp dir so tests don't pollute the main file."""
    src = os.path.join(os.path.dirname(__file__), "policies.json")
    dst = tmp_path / "policies.json"
    shutil.copy(src, dst)
    return str(dst)


@pytest.fixture
def pap(tmp_policies):
    return PAP(policies_path=tmp_policies)


@pytest.fixture
def empty_pap(tmp_path):
    p = tmp_path / "empty.json"
    p.write_text("[]")
    return PAP(policies_path=str(p))


# =====================================================================
# TASK 1: add_policy
# =====================================================================
class TestTask1AddPolicy:

    def test_add_valid_policy(self, empty_pap):
        policy = {
            "policy_id": "TEST001",
            "description": "test",
            "effect": "Permit",
            "subject": {"role": "faculty"},
            "action": "view_grade",
            "resource": {"type": "grade_record"},
            "priority": 10
        }
        assert empty_pap.add_policy(policy) is True
        assert len(empty_pap.policies) == 1

    def test_reject_duplicate_id(self, pap):
        existing = pap.policies[0].copy()
        assert pap.add_policy(existing) is False

    def test_reject_missing_field(self, empty_pap):
        bad = {"policy_id": "X", "description": "", "effect": "Permit"}
        assert empty_pap.add_policy(bad) is False

    def test_reject_invalid_effect(self, empty_pap):
        bad = {
            "policy_id": "X", "description": "x", "effect": "Maybe",
            "subject": {}, "action": "a", "resource": {}, "priority": 1
        }
        assert empty_pap.add_policy(bad) is False

    def test_reject_non_integer_priority(self, empty_pap):
        bad = {
            "policy_id": "X", "description": "x", "effect": "Permit",
            "subject": {}, "action": "a", "resource": {}, "priority": "high"
        }
        assert empty_pap.add_policy(bad) is False

    def test_reject_empty_action(self, empty_pap):
        bad = {
            "policy_id": "X", "description": "x", "effect": "Permit",
            "subject": {}, "action": "", "resource": {}, "priority": 1
        }
        assert empty_pap.add_policy(bad) is False

    def test_reject_non_dict_subject(self, empty_pap):
        bad = {
            "policy_id": "X", "description": "x", "effect": "Permit",
            "subject": "faculty", "action": "a", "resource": {}, "priority": 1
        }
        assert empty_pap.add_policy(bad) is False

    def test_reject_non_dict_resource(self, empty_pap):
        bad = {
            "policy_id": "X", "description": "x", "effect": "Permit",
            "subject": {}, "action": "a", "resource": "grade", "priority": 1
        }
        assert empty_pap.add_policy(bad) is False

    def test_reject_non_dict_policy(self, empty_pap):
        assert empty_pap.add_policy("not a dict") is False
        assert empty_pap.add_policy(None) is False
        assert empty_pap.add_policy(42) is False

    def test_persistence(self, empty_pap, tmp_path):
        policy = {
            "policy_id": "PERSIST001", "description": "x", "effect": "Permit",
            "subject": {}, "action": "a", "resource": {}, "priority": 1
        }
        empty_pap.add_policy(policy)
        # reload from disk
        pap2 = PAP(policies_path=empty_pap.policies_path)
        assert len(pap2.policies) == 1
        assert pap2.policies[0]["policy_id"] == "PERSIST001"


# =====================================================================
# TASK 2: delete_policy
# =====================================================================
class TestTask2DeletePolicy:

    def test_delete_existing(self, pap):
        initial = len(pap.policies)
        assert pap.delete_policy("P001") is True
        assert len(pap.policies) == initial - 1

    def test_delete_nonexistent(self, pap):
        initial = len(pap.policies)
        assert pap.delete_policy("DOES_NOT_EXIST") is False
        assert len(pap.policies) == initial

    def test_delete_persists(self, pap):
        pap.delete_policy("P002")
        pap2 = PAP(policies_path=pap.policies_path)
        ids = [p["policy_id"] for p in pap2.policies]
        assert "P002" not in ids

    def test_delete_from_empty(self, empty_pap):
        assert empty_pap.delete_policy("anything") is False

    def test_delete_multiple(self, pap):
        pap.delete_policy("P001")
        pap.delete_policy("P002")
        pap.delete_policy("P003")
        ids = [p["policy_id"] for p in pap.policies]
        assert "P001" not in ids
        assert "P002" not in ids
        assert "P003" not in ids


# =====================================================================
# TASK 3: get_applicable_policies
# =====================================================================
class TestTask3GetApplicablePolicies:

    def test_cosc_faculty_view_grade(self, pap):
        req = {
            "subject": {"role": "faculty", "department": "cosc", "id": "F001"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "cosc"}
        }
        applicable = pap.get_applicable_policies(req)
        ids = [p["policy_id"] for p in applicable]
        assert "P001" in ids

    def test_student_different_action_excluded(self, pap):
        req = {
            "subject": {"role": "student", "id": "I12345678"},
            "action": "upload_content",
            "resource": {"type": "blackboard_content"}
        }
        applicable = pap.get_applicable_policies(req)
        # P002 is view_grade, should not apply
        ids = [p["policy_id"] for p in applicable]
        assert "P002" not in ids

    def test_wrong_department_excluded(self, pap):
        req = {
            "subject": {"role": "faculty", "department": "math"},
            "action": "view_grade",
            "resource": {"type": "grade_record", "department": "math"}
        }
        applicable = pap.get_applicable_policies(req)
        # P001 requires cosc department
        ids = [p["policy_id"] for p in applicable]
        assert "P001" not in ids

    def test_empty_subject_policy_matches(self, pap):
        # P004 has empty subject {} - should match any subject
        req = {
            "subject": {"role": "anyone"},
            "action": "modify_grade",
            "resource": {"type": "grade_record"}
        }
        applicable = pap.get_applicable_policies(req)
        ids = [p["policy_id"] for p in applicable]
        assert "P004" in ids

    def test_ta_view_roster(self, pap):
        req = {
            "subject": {"role": "ta", "id": "I87654321"},
            "action": "view_roster",
            "resource": {"type": "course_roster", "course": "COSC4350"}
        }
        applicable = pap.get_applicable_policies(req)
        ids = [p["policy_id"] for p in applicable]
        assert "P003" in ids

    def test_no_matching_action_returns_empty(self, pap):
        req = {
            "subject": {"role": "faculty"},
            "action": "delete_course",
            "resource": {"type": "course"}
        }
        applicable = pap.get_applicable_policies(req)
        assert applicable == []

    def test_returns_list(self, pap):
        req = {"subject": {}, "action": "view_grade", "resource": {}}
        result = pap.get_applicable_policies(req)
        assert isinstance(result, list)

    def test_missing_subject_key_kept(self, pap):
        # request doesn't specify department; P001 requires dept=cosc.
        # loose filter should keep it (PDP decides).
        req = {
            "subject": {"role": "faculty"},
            "action": "view_grade",
            "resource": {"type": "grade_record"}
        }
        applicable = pap.get_applicable_policies(req)
        ids = [p["policy_id"] for p in applicable]
        assert "P001" in ids


# =====================================================================
# BONUS: detect_conflicts
# =====================================================================
class TestBonusDetectConflicts:

    def test_no_conflicts_in_seed(self, pap):
        # seed policies have no overlapping subject/action/resource with diff effects
        conflicts = pap.detect_conflicts()
        assert conflicts == []

    def test_detect_direct_conflict(self, empty_pap):
        permit = {
            "policy_id": "PERMIT01", "description": "p", "effect": "Permit",
            "subject": {"role": "ta"}, "action": "view_grade",
            "resource": {"type": "grade_record"}, "priority": 10
        }
        deny = {
            "policy_id": "DENY01", "description": "d", "effect": "Deny",
            "subject": {"role": "ta"}, "action": "view_grade",
            "resource": {"type": "grade_record"}, "priority": 20
        }
        empty_pap.add_policy(permit)
        empty_pap.add_policy(deny)
        conflicts = empty_pap.detect_conflicts()
        assert len(conflicts) == 1
        assert ("PERMIT01", "DENY01") in conflicts

    def test_same_effect_no_conflict(self, empty_pap):
        a = {
            "policy_id": "A", "description": "a", "effect": "Permit",
            "subject": {"role": "ta"}, "action": "view",
            "resource": {"type": "r"}, "priority": 10
        }
        b = {
            "policy_id": "B", "description": "b", "effect": "Permit",
            "subject": {"role": "ta"}, "action": "view",
            "resource": {"type": "r"}, "priority": 20
        }
        empty_pap.add_policy(a)
        empty_pap.add_policy(b)
        assert empty_pap.detect_conflicts() == []

    def test_different_subject_no_conflict(self, empty_pap):
        a = {
            "policy_id": "A", "description": "a", "effect": "Permit",
            "subject": {"role": "ta"}, "action": "view",
            "resource": {"type": "r"}, "priority": 10
        }
        b = {
            "policy_id": "B", "description": "b", "effect": "Deny",
            "subject": {"role": "student"}, "action": "view",
            "resource": {"type": "r"}, "priority": 20
        }
        empty_pap.add_policy(a)
        empty_pap.add_policy(b)
        assert empty_pap.detect_conflicts() == []
