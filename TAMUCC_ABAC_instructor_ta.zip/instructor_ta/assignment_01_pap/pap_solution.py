"""
TAMUCC Agent-Based Systems | Assignment 01
Policy Administration Point (PAP) - INSTRUCTOR REFERENCE SOLUTION
DO_NOT_SHARE with students.
"""
import json
import os
from typing import List, Dict, Any, Optional


class PAP:
    """
    Policy Administration Point for the TAMUCC ABAC system.

    The PAP is responsible for CRUD operations on the policy store
    and for pre-filtering policies relevant to a given access request.
    It is *not* responsible for making access decisions - that is the PDP.
    """

    VALID_EFFECTS = {"Permit", "Deny"}
    REQUIRED_POLICY_FIELDS = {
        "policy_id", "description", "effect",
        "subject", "action", "resource", "priority"
    }

    def __init__(self, policies_path: str = "policies.json"):
        self.policies_path = policies_path
        self.policies: List[Dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        if os.path.exists(self.policies_path):
            with open(self.policies_path, "r") as f:
                self.policies = json.load(f)
        else:
            self.policies = []

    def _save(self) -> None:
        with open(self.policies_path, "w") as f:
            json.dump(self.policies, f, indent=2)

    # ---------- TASK 1 ----------
    def add_policy(self, policy: Dict[str, Any]) -> bool:
        """Validate and append a policy. Returns True on success, False on failure."""
        # schema check
        if not isinstance(policy, dict):
            return False
        if not self.REQUIRED_POLICY_FIELDS.issubset(policy.keys()):
            return False
        if policy["effect"] not in self.VALID_EFFECTS:
            return False
        if not isinstance(policy["priority"], int):
            return False
        if not isinstance(policy["subject"], dict):
            return False
        if not isinstance(policy["resource"], dict):
            return False
        if not isinstance(policy["action"], str) or not policy["action"]:
            return False
        # uniqueness
        if any(p["policy_id"] == policy["policy_id"] for p in self.policies):
            return False
        self.policies.append(policy)
        self._save()
        return True

    # ---------- TASK 2 ----------
    def delete_policy(self, policy_id: str) -> bool:
        """Remove a policy by id. Returns True if removed, False otherwise."""
        for i, p in enumerate(self.policies):
            if p["policy_id"] == policy_id:
                del self.policies[i]
                self._save()
                return True
        return False

    # ---------- TASK 3 ----------
    def get_applicable_policies(self, request_attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Pre-filter: return policies that *might* apply to the request.
        The PDP does the precise matching later. Here we just need a loose filter.

        A policy is pre-applicable if:
        - The action matches the request's action (or policy action is '*'), AND
        - No subject attribute in the policy conflicts with a provided request attribute.
          (If the request doesn't specify an attribute the policy requires, we still
          include it - the PDP will make the final call.)
        """
        req_subject = request_attrs.get("subject", {})
        req_action = request_attrs.get("action")
        req_resource = request_attrs.get("resource", {})

        applicable = []
        for policy in self.policies:
            # action filter
            if policy["action"] != "*" and policy["action"] != req_action:
                continue
            # loose subject filter
            conflict = False
            for k, v in policy["subject"].items():
                if k in req_subject and req_subject[k] != v:
                    conflict = True
                    break
            if conflict:
                continue
            # loose resource filter
            for k, v in policy["resource"].items():
                if k in req_resource and req_resource[k] != v:
                    conflict = True
                    break
            if conflict:
                continue
            applicable.append(policy)
        return applicable

    # ---------- BONUS TASK ----------
    def detect_conflicts(self) -> List[tuple]:
        """
        Return a list of (policy_id_a, policy_id_b) tuples where two policies
        have the same subject, action, and resource but different effects.
        """
        conflicts = []
        n = len(self.policies)
        for i in range(n):
            for j in range(i + 1, n):
                a, b = self.policies[i], self.policies[j]
                if (a["subject"] == b["subject"]
                        and a["action"] == b["action"]
                        and a["resource"] == b["resource"]
                        and a["effect"] != b["effect"]):
                    conflicts.append((a["policy_id"], b["policy_id"]))
        return conflicts
