"""
TAMUCC Agent-Based Systems | Assignment 01
Policy Administration Point (PAP) - Student Template

Your job: implement the four methods marked with TODO.
You may add helper methods if you wish, but do not change the
signatures of the required methods.

Run tests with:  pytest -v
Run the demo:    python main.py
"""
import json
import os
from typing import List, Dict, Any, Optional


class PAP:
    """
    Policy Administration Point for the TAMUCC ABAC system.

    The PAP is responsible for CRUD operations on the policy store
    and for pre-filtering policies relevant to a given access request.
    It is *not* responsible for making access decisions - that is the PDP's job.
    """

    VALID_EFFECTS = {"Permit", "Deny"}
    REQUIRED_POLICY_FIELDS = {
        "policy_id", "description", "effect",
        "subject", "action", "resource", "priority"
    }

    def __init__(self, policies_path: str = "policies.json"):
        self.policies_path = policies_path
        self.policies: List[Dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        if os.path.exists(self.policies_path):
            with open(self.policies_path, "r") as f:
                self.policies = json.load(f)
        else:
            self.policies = []

    def _save(self) -> None:
        with open(self.policies_path, "w") as f:
            json.dump(self.policies, f, indent=2)

    # ---------- TASK 1 ----------
    def add_policy(self, policy: Dict[str, Any]) -> bool:
        """
        Validate and append a policy to the store.

        A policy must:
          - be a dict
          - contain every field in REQUIRED_POLICY_FIELDS
          - have 'effect' in VALID_EFFECTS
          - have an integer 'priority'
          - have a dict 'subject' and dict 'resource'
          - have a non-empty string 'action'
          - have a unique 'policy_id' (not already in self.policies)

        Returns True if the policy was added, False otherwise.
        Remember to persist to disk via self._save() on success.
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 2 ----------
    def delete_policy(self, policy_id: str) -> bool:
        """
        Remove the policy with the given policy_id from the store.
        Return True if a policy was removed, False if no such id exists.
        Persist changes with self._save().
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- TASK 3 ----------
    def get_applicable_policies(self, request_attrs: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Pre-filter: return policies that *might* apply to this request.
        The PDP does the precise matching later. Here we do a LOOSE filter.

        request_attrs has this shape:
            {"subject": {...}, "action": "...", "resource": {...}}

        A policy is pre-applicable if:
          - policy["action"] == request action, OR policy["action"] == "*"
          - No subject key present in BOTH policy and request has a different value
          - No resource key present in BOTH policy and request has a different value

        Note: if the request doesn't provide a key that the policy specifies,
        we still keep the policy (the PDP will decide).
        """
        # TODO: implement
        raise NotImplementedError

    # ---------- BONUS TASK ----------
    def detect_conflicts(self) -> List[tuple]:
        """
        BONUS: Return a list of (policy_id_a, policy_id_b) tuples where two
        policies have identical subject, action, and resource but DIFFERENT effects
        (one Permit, one Deny). Each pair reported once, with a < b ordering.
        """
        # TODO: implement (bonus, optional)
        raise NotImplementedError
