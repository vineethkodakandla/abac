"""
TAMUCC Agent-Based Systems | Assignment 01 Demo
Policy Administration Point (PAP)

Runs a walk-through of the PAP using TAMUCC-flavored scenarios.
Useful for sanity-checking your implementation before running pytest.
"""
from pap import PAP


def banner(title):
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)


def main():
    banner("TAMUCC ABAC - Policy Administration Point Demo")
    pap = PAP(policies_path="policies.json")
    print(f"Loaded {len(pap.policies)} policies from policies.json")
    for p in pap.policies:
        print(f"  - {p['policy_id']}: {p['description']}")

    # --- add_policy ---
    banner("Adding a new policy for MATH faculty")
    new_policy = {
        "policy_id": "P006",
        "description": "MATH faculty can view grades in MATH courses",
        "effect": "Permit",
        "subject": {"role": "faculty", "department": "math"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "department": "math"},
        "priority": 10
    }
    ok = pap.add_policy(new_policy)
    print(f"add_policy returned: {ok}")
    print(f"Total policies now: {len(pap.policies)}")

    # --- get_applicable_policies ---
    banner("Scenario 1: COSC faculty views grades in COSC3310")
    req = {
        "subject": {"role": "faculty", "department": "cosc", "id": "F001"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "department": "cosc", "course": "COSC3310"}
    }
    hits = pap.get_applicable_policies(req)
    print(f"Applicable policies: {[p['policy_id'] for p in hits]}")

    banner("Scenario 2: Islander views their own grades")
    req = {
        "subject": {"role": "student", "id": "I12345678"},
        "action": "view_grade",
        "resource": {"type": "grade_record", "owner": "self"}
    }
    hits = pap.get_applicable_policies(req)
    print(f"Applicable policies: {[p['policy_id'] for p in hits]}")

    banner("Scenario 3: Visitor attempts to modify a grade")
    req = {
        "subject": {"badge_id": "VISITOR-001"},
        "action": "modify_grade",
        "resource": {"type": "grade_record"}
    }
    hits = pap.get_applicable_policies(req)
    print(f"Applicable policies: {[p['policy_id'] for p in hits]}")

    # --- detect_conflicts (bonus) ---
    banner("Checking for policy conflicts")
    try:
        conflicts = pap.detect_conflicts()
        print(f"Conflicts found: {conflicts}")
    except NotImplementedError:
        print("(detect_conflicts not implemented - bonus task)")

    # --- delete_policy ---
    banner("Deleting P006")
    ok = pap.delete_policy("P006")
    print(f"delete_policy returned: {ok}")
    print(f"Total policies now: {len(pap.policies)}")


if __name__ == "__main__":
    main()
