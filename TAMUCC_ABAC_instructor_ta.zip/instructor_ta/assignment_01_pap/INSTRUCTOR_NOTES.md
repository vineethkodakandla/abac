# Assignment 01 — Instructor Notes (PAP)

## Learning objective alignment

This assignment exercises (1) structured data handling in Python, (2) simple
validation, (3) filtering vs matching as distinct concepts, and (4) conflict
detection as a light taste of formal analysis.

## Reference solution

`pap_solution.py` — drop-in complete implementation. Marked `DO_NOT_SHARE`.
All 30 tests pass.

## Expected student stumbling points

1. **`get_applicable_policies` as exact match vs loose filter.** The most
   common mistake. Students read the prompt and think "return policies that
   match" and write an exact matcher. The test
   `test_missing_subject_key_kept` fails when they do this. Emphasize in
   lecture that this is a pre-filter — the PDP makes the precise call.

2. **Validation short-circuiting.** Some students use `if policy.get("x")`
   which returns `None` truthy-test failures. The correct pattern is to
   check for membership (`"x" in policy`) and then type-check.

3. **Persistence forgetting.** Students add to `self.policies` but forget
   `self._save()`. `test_persistence` catches this.

4. **Duplicate IDs.** Students use `any()` over a generator but forget that
   `policy_id` equality must be checked. Straightforward once pointed out.

## Running validation

```bash
cd instructor_ta/assignment_01_pap/
bash validate_solutions.sh
# Expected: 30 passed
```

## Common manual-review items

- Is the reflection docstring **at the top of the file**, or buried somewhere?
- Are there leftover `print()` debug statements?
- Is the `_save()` call inside `add_policy` AFTER the append, not before?

## Grading tip

`TestTask3GetApplicablePolicies::test_missing_subject_key_kept` is the
single most diagnostic test. If a student fails only this one but passes
everything else, they've implemented an exact match — give partial credit
for the idea but note the conceptual confusion in their rubric feedback.
