#!/usr/bin/env bash
# Validate Assignment 01 reference solution against test suite.
# Before distributing to students, this must print "30 passed".
set -e
cd "$(dirname "$0")"

# Swap in reference solution
cp pap.py .pap_student_backup.py
cp pap_solution.py pap.py

# Reset policies.json in case a previous run mutated it
if [ -f .policies_backup.json ]; then
  cp .policies_backup.json policies.json
else
  cp policies.json .policies_backup.json
fi

python -m pytest -v --tb=short

# Restore student template
mv .pap_student_backup.py pap.py
cp .policies_backup.json policies.json
