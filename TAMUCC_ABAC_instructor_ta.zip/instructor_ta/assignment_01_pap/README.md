# Assignment 01 — Policy Administration Point (PAP)

**Texas A&M University – Corpus Christi**
**COSC Department | Agent-Based Systems**

## What you're building

The Policy Administration Point — the agent responsible for CRUD operations
on the TAMUCC access control policy store. You implement four methods in
`pap.py`. The `policies.json` file your PAP maintains is the contract
between you and the PDP (Assignment 02).

See `Assignment_01_Worksheet.docx` for the full specification.

## Files in this directory

| File | Purpose |
|------|---------|
| `pap.py` | Student template with TODO blocks — edit this |
| `policies.json` | Seed policy store (Islanders, COSC/MATH faculty, TAs, visitors) |
| `policies.schema.json` | JSON Schema for the policy store (the "output contract") |
| `test_pap.py` | Task-grouped pytest suite — 27 test cases |
| `test_output_contract.py` | Validates that your policies.json still matches the schema |
| `main.py` | TAMUCC-themed demo; useful for sanity checks |
| `Assignment_01_Worksheet.docx` | Full written spec, grading rubric, submission instructions |

## Setup

```bash
pip install pytest jsonschema
```

## Run

```bash
pytest -v                   # all tests
pytest test_pap.py -v       # only the task tests
python main.py              # TAMUCC walk-through
```

## Submission

Zip file `Last-First-A01.zip` containing `pap.py` and `policies.json` →
submit on Blackboard. Do **not** include `__pycache__` or `.pytest_cache`.
