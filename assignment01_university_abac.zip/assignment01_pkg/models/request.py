"""
models/request.py
-----------------
Defines AccessRequest and AccessDecision dataclasses used by PDP and PEP agents.

DO NOT MODIFY THIS FILE.
These classes are provided now so that your PAP implementation is compatible
with Assignments 02 and 03 from the start.
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class AccessRequest:
    """
    Represents an incoming request to access a university resource.

    Fields
    ------
    request_id      : Unique identifier for this request, e.g. 'REQ-abc123'
    subject_attrs   : Attributes of the person making the request
                      e.g. {"role": "student", "department": "cs", "year": "3"}
    resource_attrs  : Attributes of the resource being accessed
                      e.g. {"type": "course_material", "department": "cs", "course": "CS101"}
    action          : The action being attempted, e.g. "read", "submit", "delete"
    environment     : Contextual info, e.g. {"time_of_day": "morning", "ip": "10.0.0.1"}
    """
    request_id:     str
    subject_attrs:  dict[str, Any]
    resource_attrs: dict[str, Any]
    action:         str
    environment:    dict[str, Any]


@dataclass
class AccessDecision:
    """
    Represents the decision returned by the PDP after evaluating a request.

    Fields
    ------
    request_id          : Mirrors the request's ID for tracing
    decision            : "permit", "deny", or "not_applicable"
    reason              : Human-readable explanation of the decision
    matched_policy_id   : ID of the policy that triggered the decision, or None
    """
    request_id:         str
    decision:           str
    reason:             str
    matched_policy_id:  str | None
