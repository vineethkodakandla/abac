"""
models/policy.py
----------------
Defines the Policy dataclass used throughout the ABAC system.

DO NOT MODIFY THIS FILE.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Policy:
    """
    Represents a single access control policy in the university ABAC system.

    Fields
    ------
    policy_id       : Unique identifier, e.g. 'POL-001'
    name            : Short human-readable name
    description     : One-sentence explanation of what the policy allows/denies
    subject_attrs   : Attributes describing WHO the policy applies to
                      e.g. {"role": "professor", "department": "cs"}
    resource_attrs  : Attributes describing WHAT resource is targeted
                      e.g. {"type": "grade_record", "department": "cs"}
    actions         : List of permitted/denied verbs
                      e.g. ["read", "write"]
    effect          : "permit" or "deny"
    priority        : Higher number = evaluated first by PDP (default 0)
    """
    policy_id:      str
    name:           str
    description:    str
    subject_attrs:  dict[str, Any]
    resource_attrs: dict[str, Any]
    actions:        list[str]
    effect:         str
    priority:       int = 0
