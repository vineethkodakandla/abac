"""
main.py
-------
Demo script that wires all three agents together and runs sample
university access control scenarios.

Run with:
    python main.py

Note: PDP and PEP agents are stubs in Assignment 01.
      Full implementations come in Assignments 02 and 03.
"""

from agents.pap_agent import PAPAgent


def print_section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def main():
    # ── Initialize PAP ────────────────────────────────────────────
    print_section("Initializing University ABAC System — PAP Agent")
    pap = PAPAgent(storage_path="storage/policies.json")

    print(f"\nLoaded {len(pap.list_policies())} policies from storage.")
    print("\nExisting policies:")
    for p in pap.list_policies():
        print(f"  [{p.policy_id}] {p.name} — {p.effect.upper()} (priority {p.priority})")

    # ── Add new policies ──────────────────────────────────────────
    print_section("Adding New Policies")

    pap.add_policy(
        name="Department Head Full Access",
        description="Department heads can read, write, and delete any record in their department.",
        subject_attrs={"role": "dept_head"},
        resource_attrs={"type": "grade_record"},
        actions=["read", "write", "delete"],
        effect="permit",
        priority=20,
    )
    print("  Added: Department Head Full Access")

    pap.add_policy(
        name="Deny Access After Hours",
        description="All students are denied access to lab resources outside working hours.",
        subject_attrs={"role": "student"},
        resource_attrs={"type": "lab_resource"},
        actions=["read", "write"],
        effect="deny",
        priority=80,
    )
    print("  Added: Deny Access After Hours")

    print(f"\nTotal policies now: {len(pap.list_policies())}")

    # ── Query applicable policies ─────────────────────────────────
    print_section("Querying Applicable Policies for Sample Requests")

    scenarios = [
        {
            "label": "Enrolled student trying to READ course material",
            "subject": {"role": "student", "status": "enrolled"},
            "resource": {"type": "course_material"},
            "action":  "read",
        },
        {
            "label": "Suspended student trying to READ course material",
            "subject": {"role": "student", "status": "suspended"},
            "resource": {"type": "course_material"},
            "action":  "read",
        },
        {
            "label": "CS Professor trying to WRITE grade records",
            "subject": {"role": "professor", "department": "cs"},
            "resource": {"type": "grade_record", "department": "cs"},
            "action":  "write",
        },
        {
            "label": "External visitor trying to DELETE admin documents",
            "subject": {"role": "external_visitor"},
            "resource": {"type": "admin_document"},
            "action":  "delete",
        },
    ]

    for s in scenarios:
        print(f"\n  Scenario: {s['label']}")
        matches = pap.get_applicable_policies(s["subject"], s["resource"], s["action"])
        if matches:
            for m in matches:
                print(f"    → [{m.policy_id}] {m.name} — {m.effect.upper()} (priority {m.priority})")
        else:
            print("    → No applicable policies found.")

    # ── Delete a policy ───────────────────────────────────────────
    print_section("Deleting a Policy")
    success = pap.delete_policy("POL-003")
    print(f"  Deleted POL-003: {success}")
    print(f"  Policies remaining: {len(pap.list_policies())}")

    print("\nDemo complete. Run tests with:")
    print("  python -m pytest tests/test_assignment01.py -v\n")


if __name__ == "__main__":
    main()
