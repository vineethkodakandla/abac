"""
tests/test_assignment01.py
--------------------------
Automated test suite for Assignment 01 — PAP Agent.

Run with:
    python -m pytest tests/test_assignment01.py -v

Point breakdown:
    Task 1 (add_policy)                — 30 pts  — tests marked task1
    Task 2 (delete_policy)             — 20 pts  — tests marked task2
    Task 3 (get_applicable_policies)   — 35 pts  — tests marked task3
    Task 4 (detect_conflicts) [BONUS]  — +15 pts — tests marked task4

Note: Code quality (15 pts) is assessed manually by the instructor.
"""

import json
import os
import pytest
from models.policy import Policy
from agents.pap_agent import PAPAgent


# ── Fixture ───────────────────────────────────────────────────────────────────

TEST_STORAGE = "tests/test_policies.json"

@pytest.fixture(autouse=True)
def clean_storage():
    """Start each test with a fresh storage file using university seed policies."""
    seed = [
        {
            "policy_id": "POL-001",
            "name": "Professor Full Access to Own Department Grades",
            "description": "Professors can read and write grade records in their department.",
            "subject_attrs": {"role": "professor", "department": "cs"},
            "resource_attrs": {"type": "grade_record", "department": "cs"},
            "actions": ["read", "write"],
            "effect": "permit",
            "priority": 10,
        },
        {
            "policy_id": "POL-002",
            "name": "Student Read Own Course Materials",
            "description": "Enrolled students can read course materials.",
            "subject_attrs": {"role": "student", "status": "enrolled"},
            "resource_attrs": {"type": "course_material"},
            "actions": ["read"],
            "effect": "permit",
            "priority": 5,
        },
        {
            "policy_id": "POL-003",
            "name": "Deny Suspended Students All Access",
            "description": "Suspended students are denied all access.",
            "subject_attrs": {"role": "student", "status": "suspended"},
            "resource_attrs": {},
            "actions": ["read", "write", "submit", "delete"],
            "effect": "deny",
            "priority": 100,
        },
    ]
    os.makedirs("tests", exist_ok=True)
    with open(TEST_STORAGE, "w") as f:
        json.dump(seed, f)
    yield
    if os.path.exists(TEST_STORAGE):
        os.remove(TEST_STORAGE)


@pytest.fixture
def pap():
    return PAPAgent(storage_path=TEST_STORAGE)


# ═════════════════════════════════════════════════════════════════════════════
# TASK 1 — add_policy()                                            [30 points]
# ═════════════════════════════════════════════════════════════════════════════

class TestTask1AddPolicy:

    def test_add_policy_returns_policy_object(self, pap):
        """add_policy() must return a Policy object."""
        result = pap.add_policy(
            name="TA Read Assignments",
            description="TAs can read assignment submissions.",
            subject_attrs={"role": "ta"},
            resource_attrs={"type": "assignment"},
            actions=["read"],
            effect="permit",
        )
        assert isinstance(result, Policy), "add_policy() must return a Policy object"

    def test_add_policy_generates_unique_id(self, pap):
        """Each call to add_policy() must produce a different policy_id."""
        p1 = pap.add_policy("P1", "", {"role": "ta"}, {}, ["read"], "permit")
        p2 = pap.add_policy("P2", "", {"role": "ta"}, {}, ["read"], "permit")
        assert p1.policy_id != p2.policy_id, "Each policy must have a unique policy_id"

    def test_add_policy_id_is_string(self, pap):
        """policy_id must be a non-empty string."""
        p = pap.add_policy("P", "", {"role": "ta"}, {}, ["read"], "permit")
        assert isinstance(p.policy_id, str) and len(p.policy_id) > 0

    def test_add_policy_stores_in_memory(self, pap):
        """After add_policy(), the policy must be retrievable via get_policy()."""
        p = pap.add_policy("Admin Doc Access", "", {"role": "admin_staff"},
                           {"type": "admin_document"}, ["read", "write"], "permit")
        retrieved = pap.get_policy(p.policy_id)
        assert retrieved is not None
        assert retrieved.policy_id == p.policy_id

    def test_add_policy_persists_to_disk(self, pap):
        """add_policy() must save the policy to the JSON storage file."""
        p = pap.add_policy("Persist Test", "", {"role": "professor"},
                           {"type": "research_paper"}, ["read"], "permit")
        # Load fresh instance to verify persistence
        pap2 = PAPAgent(storage_path=TEST_STORAGE)
        assert pap2.get_policy(p.policy_id) is not None

    def test_add_policy_permit_effect(self, pap):
        """add_policy() must accept 'permit' as a valid effect."""
        p = pap.add_policy("Test", "", {"role": "student"}, {}, ["read"], "permit")
        assert p.effect == "permit"

    def test_add_policy_deny_effect(self, pap):
        """add_policy() must accept 'deny' as a valid effect."""
        p = pap.add_policy("Test", "", {"role": "student"}, {}, ["read"], "deny")
        assert p.effect == "deny"

    def test_add_policy_invalid_effect_raises_value_error(self, pap):
        """add_policy() must raise ValueError when effect is not 'permit' or 'deny'."""
        with pytest.raises(ValueError):
            pap.add_policy("Bad Policy", "", {"role": "student"}, {}, ["read"], "allow")

    def test_add_policy_invalid_effect_maybe(self, pap):
        """add_policy() must raise ValueError for effect='maybe'."""
        with pytest.raises(ValueError):
            pap.add_policy("Bad", "", {}, {}, ["read"], "maybe")

    def test_add_policy_stores_correct_attributes(self, pap):
        """All passed attributes must be stored correctly on the Policy object."""
        p = pap.add_policy(
            name="Dean Full Access",
            description="Dean can access all records.",
            subject_attrs={"role": "dean"},
            resource_attrs={"type": "grade_record"},
            actions=["read", "write", "delete"],
            effect="permit",
            priority=50,
        )
        assert p.name == "Dean Full Access"
        assert p.subject_attrs == {"role": "dean"}
        assert p.resource_attrs == {"type": "grade_record"}
        assert p.actions == ["read", "write", "delete"]
        assert p.effect == "permit"
        assert p.priority == 50

    def test_add_policy_increases_list_count(self, pap):
        """list_policies() count must increase by 1 after each add_policy()."""
        before = len(pap.list_policies())
        pap.add_policy("Extra", "", {"role": "ta"}, {}, ["read"], "permit")
        assert len(pap.list_policies()) == before + 1


# ═════════════════════════════════════════════════════════════════════════════
# TASK 2 — delete_policy()                                         [20 points]
# ═════════════════════════════════════════════════════════════════════════════

class TestTask2DeletePolicy:

    def test_delete_existing_policy_returns_true(self, pap):
        """delete_policy() must return True when the policy exists."""
        result = pap.delete_policy("POL-001")
        assert result is True

    def test_delete_missing_policy_returns_false(self, pap):
        """delete_policy() must return False when policy_id does not exist."""
        result = pap.delete_policy("POL-999")
        assert result is False

    def test_delete_removes_from_memory(self, pap):
        """After deletion, get_policy() must return None for that ID."""
        pap.delete_policy("POL-002")
        assert pap.get_policy("POL-002") is None

    def test_delete_persists_to_disk(self, pap):
        """Deletion must be saved to disk — a fresh PAPAgent must not see it."""
        pap.delete_policy("POL-001")
        pap2 = PAPAgent(storage_path=TEST_STORAGE)
        assert pap2.get_policy("POL-001") is None

    def test_delete_reduces_list_count(self, pap):
        """list_policies() count must decrease by 1 after deletion."""
        before = len(pap.list_policies())
        pap.delete_policy("POL-001")
        assert len(pap.list_policies()) == before - 1

    def test_delete_does_not_affect_other_policies(self, pap):
        """Deleting one policy must not affect others."""
        pap.delete_policy("POL-001")
        assert pap.get_policy("POL-002") is not None
        assert pap.get_policy("POL-003") is not None


# ═════════════════════════════════════════════════════════════════════════════
# TASK 3 — get_applicable_policies()                               [35 points]
# ═════════════════════════════════════════════════════════════════════════════

class TestTask3GetApplicablePolicies:

    def test_returns_list(self, pap):
        """get_applicable_policies() must return a list."""
        result = pap.get_applicable_policies({"role": "student"}, {}, "read")
        assert isinstance(result, list)

    def test_returns_policy_objects(self, pap):
        """Each item in the result must be a Policy object."""
        result = pap.get_applicable_policies(
            {"role": "student", "status": "enrolled"},
            {"type": "course_material"},
            "read"
        )
        for item in result:
            assert isinstance(item, Policy)

    def test_matches_by_action(self, pap):
        """Only policies whose actions list includes the requested action are returned."""
        # POL-002 allows "read" for enrolled students; "submit" is not in its actions
        result = pap.get_applicable_policies(
            {"role": "student", "status": "enrolled"},
            {"type": "course_material"},
            "submit"
        )
        ids = [p.policy_id for p in result]
        assert "POL-002" not in ids, "POL-002 does not include 'submit' as an action"

    def test_matches_enrolled_student_read(self, pap):
        """An enrolled student reading course material must match POL-002."""
        result = pap.get_applicable_policies(
            {"role": "student", "status": "enrolled"},
            {"type": "course_material"},
            "read"
        )
        ids = [p.policy_id for p in result]
        assert "POL-002" in ids

    def test_matches_suspended_student_any_action(self, pap):
        """A suspended student must match POL-003 for any action."""
        result = pap.get_applicable_policies(
            {"role": "student", "status": "suspended"},
            {"type": "course_material"},
            "read"
        )
        ids = [p.policy_id for p in result]
        assert "POL-003" in ids, "Suspended student policy (POL-003) must be returned"

    def test_empty_resource_attrs_matches_any_resource(self, pap):
        """A policy with empty resource_attrs must match any resource."""
        # POL-003 has empty resource_attrs — should match any resource
        result = pap.get_applicable_policies(
            {"role": "student", "status": "suspended"},
            {"type": "research_paper"},
            "read"
        )
        ids = [p.policy_id for p in result]
        assert "POL-003" in ids

    def test_no_match_returns_empty_list(self, pap):
        """If no policy matches, return an empty list."""
        result = pap.get_applicable_policies(
            {"role": "external_visitor"},
            {"type": "confidential_document"},
            "delete"
        )
        assert result == [] or isinstance(result, list)

    def test_sorted_by_priority_descending(self, pap):
        """Results must be sorted by priority from highest to lowest."""
        # Add a high-priority policy to make ordering testable
        pap.add_policy("High Priority", "", {"role": "student"}, {}, ["read"], "deny", priority=200)
        result = pap.get_applicable_policies(
            {"role": "student", "status": "suspended"},
            {},
            "read"
        )
        priorities = [p.priority for p in result]
        assert priorities == sorted(priorities, reverse=True), \
            "Policies must be sorted by priority descending"

    def test_professor_matches_grade_record(self, pap):
        """A CS professor reading grade records must match POL-001."""
        result = pap.get_applicable_policies(
            {"role": "professor", "department": "cs"},
            {"type": "grade_record", "department": "cs"},
            "read"
        )
        ids = [p.policy_id for p in result]
        assert "POL-001" in ids

    def test_unrelated_subject_key_no_match(self, pap):
        """A subject with no overlapping keys with any policy must not match those policies."""
        result = pap.get_applicable_policies(
            {"employee_id": "E999"},   # key not in any policy
            {"type": "course_material"},
            "read"
        )
        # POL-002 requires "role" or "status" key — should not match
        ids = [p.policy_id for p in result]
        assert "POL-002" not in ids


# ═════════════════════════════════════════════════════════════════════════════
# TASK 4 — detect_conflicts()  [BONUS +15 points]
# ═════════════════════════════════════════════════════════════════════════════

class TestTask4DetectConflicts:

    def test_returns_list(self, pap):
        """detect_conflicts() must return a list."""
        result = pap.detect_conflicts()
        assert isinstance(result, list)

    def test_no_conflicts_in_seed_data(self, pap):
        """The pre-seeded policies have no conflicts — must return empty list."""
        result = pap.detect_conflicts()
        assert result == []

    def test_detects_one_conflict(self, pap):
        """Adding a policy that directly contradicts an existing one must be detected."""
        # POL-001: professor/cs can read/write grade_record/cs — permit
        # Add an identical-scope DENY policy:
        pap.add_policy(
            name="Deny Professor Grade Access",
            description="Deny CS professors from accessing CS grade records.",
            subject_attrs={"role": "professor", "department": "cs"},
            resource_attrs={"type": "grade_record", "department": "cs"},
            actions=["read", "write"],
            effect="deny",
            priority=10,
        )
        result = pap.detect_conflicts()
        assert len(result) == 1, "Exactly one conflict should be found"

    def test_conflict_tuple_contains_policies(self, pap):
        """Each conflict must be a tuple of two Policy objects."""
        pap.add_policy("Conflict", "", {"role": "professor", "department": "cs"},
                       {"type": "grade_record", "department": "cs"},
                       ["read", "write"], "deny", 10)
        result = pap.detect_conflicts()
        assert len(result) == 1
        pair = result[0]
        assert isinstance(pair, tuple) and len(pair) == 2
        assert isinstance(pair[0], Policy) and isinstance(pair[1], Policy)

    def test_no_duplicate_pairs(self, pap):
        """Each conflict pair must appear only once (not both (a,b) and (b,a))."""
        pap.add_policy("C1", "", {"role": "ta"}, {"type": "course_material"},
                       ["read"], "deny", 5)
        # POL-002 is permit for student/enrolled reading course_material
        # C1 above conflicts only if attrs match exactly — this tests no duplication
        result = pap.detect_conflicts()
        seen = set()
        for a, b in result:
            key = tuple(sorted([a.policy_id, b.policy_id]))
            assert key not in seen, "Duplicate conflict pair found"
            seen.add(key)
