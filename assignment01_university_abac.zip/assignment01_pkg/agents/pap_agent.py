"""
agents/pap_agent.py
--------------------
Policy Administration Point (PAP) Agent.

The PAP is responsible for storing, retrieving, validating, and managing
all access control policies in the university ABAC system.

YOUR TASK
---------
This file contains a partially implemented PAPAgent class.
Four methods are marked with # TODO — implement each one according
to the specification in the assignment document (Section 5).

Rules
-----
- Only add code inside the # TODO blocks.
- Do not rename methods or change their signatures.
- Do not modify any other file in the project.
- Only standard Python library modules may be imported.
"""

import json
import uuid
from models.policy import Policy


class PAPAgent:
    """
    Policy Administration Point for the University ABAC System.

    Attributes
    ----------
    storage_path : str
        Path to the JSON file used for persistent policy storage.
    policies : dict[str, Policy]
        In-memory dictionary mapping policy_id -> Policy object.
    """

    def __init__(self, storage_path: str = "storage/policies.json"):
        self.storage_path = storage_path
        self.policies: dict[str, Policy] = {}
        self._load_policies()

    # =========================================================================
    # PROVIDED METHODS — do not modify
    # =========================================================================

    def _load_policies(self) -> None:
        """Load policies from the JSON storage file into self.policies."""
        try:
            with open(self.storage_path, "r") as f:
                raw = json.load(f)
                for item in raw:
                    p = Policy(**item)
                    self.policies[p.policy_id] = p
        except FileNotFoundError:
            self.policies = {}

    def _save_policies(self) -> None:
        """Persist all current policies from self.policies to the JSON file."""
        with open(self.storage_path, "w") as f:
            data = [vars(p) for p in self.policies.values()]
            json.dump(data, f, indent=2)

    def get_policy(self, policy_id: str) -> Policy | None:
        """Return the Policy with the given ID, or None if not found."""
        return self.policies.get(policy_id)

    def list_policies(self) -> list[Policy]:
        """Return a list of all stored policies."""
        return list(self.policies.values())

    # =========================================================================
    # TASK 1 — Implement add_policy()                               [30 points]
    # =========================================================================

    def add_policy(
        self,
        name:           str,
        description:    str,
        subject_attrs:  dict,
        resource_attrs: dict,
        actions:        list[str],
        effect:         str,
        priority:       int = 0,
    ) -> Policy:
        """
        Create a new policy, store it, persist it to disk, and return it.

        Parameters
        ----------
        name            : Short human-readable name for the policy.
        description     : One-sentence explanation of what the policy does.
        subject_attrs   : Dict of subject attributes, e.g. {"role": "student"}.
        resource_attrs  : Dict of resource attributes, e.g. {"type": "grade_record"}.
        actions         : List of action verbs, e.g. ["read", "write"].
        effect          : Must be exactly "permit" or "deny".
        priority        : Integer priority; higher = evaluated first (default 0).

        Returns
        -------
        Policy
            The newly created and stored Policy object.

        Raises
        ------
        ValueError
            If effect is not "permit" or "deny".

        Example
        -------
        >>> pap = PAPAgent()
        >>> p = pap.add_policy(
        ...     name="Professor Read Grades",
        ...     description="Professors can read grade records.",
        ...     subject_attrs={"role": "professor"},
        ...     resource_attrs={"type": "grade_record"},
        ...     actions=["read"],
        ...     effect="permit",
        ...     priority=5,
        ... )
        >>> print(p.effect)
        permit
        """
        # TODO: implement this method
        # Steps:
        #   1. Generate a unique policy_id using str(uuid.uuid4())
        #   2. Validate that effect is "permit" or "deny"; raise ValueError if not
        #   3. Create a Policy object using all parameters + policy_id
        #   4. Add it to self.policies (keyed by policy_id)
        #   5. Call self._save_policies()
        #   6. Return the Policy object
        pass

    # =========================================================================
    # TASK 2 — Implement delete_policy()                            [20 points]
    # =========================================================================

    def delete_policy(self, policy_id: str) -> bool:
        """
        Remove a policy from storage by its ID.

        Parameters
        ----------
        policy_id : str
            The ID of the policy to delete.

        Returns
        -------
        bool
            True  — policy existed and was deleted.
            False — policy_id was not found; nothing changed.

        Example
        -------
        >>> pap = PAPAgent()
        >>> result = pap.delete_policy("POL-001")
        >>> print(result)
        True
        >>> result = pap.delete_policy("POL-999")
        >>> print(result)
        False
        """
        # TODO: implement this method
        # Steps:
        #   1. Check if policy_id is in self.policies
        #   2. If NOT found, return False
        #   3. If found, delete it from self.policies
        #   4. Call self._save_policies()
        #   5. Return True
        pass

    # =========================================================================
    # TASK 3 — Implement get_applicable_policies()                  [35 points]
    # =========================================================================

    def get_applicable_policies(
        self,
        subject_attrs:  dict,
        resource_attrs: dict,
        action:         str,
    ) -> list[Policy]:
        """
        Return all policies that are potentially applicable to a given request.

        This method is the main interface between the PAP and the PDP agent.
        It does NOT make a final Permit/Deny decision — it pre-filters policies
        so the PDP receives only relevant candidates.

        A policy is considered applicable if ALL THREE of the following hold:
          (a) action is in policy.actions
          (b) At least one key in policy.subject_attrs exists in subject_attrs
          (c) policy.resource_attrs is empty  OR  at least one key in
              policy.resource_attrs exists in resource_attrs

        Parameters
        ----------
        subject_attrs  : Attributes of the requesting user.
        resource_attrs : Attributes of the resource being accessed.
        action         : The action being attempted (e.g. "read").

        Returns
        -------
        list[Policy]
            Matching policies sorted by priority descending (highest first).

        Example
        -------
        >>> pap = PAPAgent()
        >>> results = pap.get_applicable_policies(
        ...     subject_attrs={"role": "student", "status": "enrolled"},
        ...     resource_attrs={"type": "course_material"},
        ...     action="read",
        ... )
        >>> print(results[0].name)
        Student Read Own Course Materials
        """
        # TODO: implement this method
        # Steps:
        #   1. Iterate over all policies in self.policies
        #   2. For each policy, check conditions (a), (b), (c) above
        #   3. Collect matching policies into a list
        #   4. Sort the list by policy.priority descending
        #   5. Return the sorted list
        pass

    # =========================================================================
    # TASK 4 (BONUS) — Implement detect_conflicts()                [+15 points]
    # =========================================================================

    def detect_conflicts(self) -> list[tuple[Policy, Policy]]:
        """
        Find all pairs of policies that directly contradict each other.

        Two policies conflict when ALL of the following are true:
          - They have identical subject_attrs
          - They have identical resource_attrs
          - They have identical actions (order does not matter)
          - They have opposite effects ("permit" vs "deny")

        Returns
        -------
        list[tuple[Policy, Policy]]
            List of conflicting (policy_a, policy_b) pairs.
            Each pair appears only once (do not include both (a,b) and (b,a)).
            Returns an empty list if no conflicts exist.

        Example
        -------
        >>> # After adding two conflicting policies:
        >>> conflicts = pap.detect_conflicts()
        >>> print(len(conflicts))
        1
        """
        # TODO: implement this method (BONUS)
        # Steps:
        #   1. Get all policies as a list
        #   2. Use nested loops or itertools.combinations to check all pairs
        #   3. For each pair, check whether they conflict (see criteria above)
        #   4. Collect and return conflicting pairs — each pair only once
        pass
