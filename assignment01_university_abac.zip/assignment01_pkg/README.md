# Assignment 01 — PAP Agent
## University ABAC System

### Setup

No external packages needed. Python 3.10+ required.

```bash
# Run the demo
python main.py

# Run the test suite
python -m pytest tests/test_assignment01.py -v
```

### Your Task

Open `agents/pap_agent.py` and implement the four methods marked with `# TODO`.
Do **not** modify any other file.

### Project Structure

```
assignment01/
├── agents/
│   └── pap_agent.py        ← YOUR WORK GOES HERE
├── models/
│   ├── policy.py           (do not modify)
│   └── request.py          (do not modify)
├── storage/
│   └── policies.json       (pre-seeded data)
├── tests/
│   └── test_assignment01.py (grading tests)
├── main.py                 (demo — read only)
└── README.md
```

### Submission

Submit only `agents/pap_agent.py` via the course portal.
